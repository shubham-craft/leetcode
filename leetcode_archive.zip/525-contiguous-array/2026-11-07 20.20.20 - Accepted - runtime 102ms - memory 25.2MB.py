class Solution:
    def findMaxLength(self, nums: List[int]) -> int:
        n = len(nums)
        for i in range(n):
            num = nums[i]
            if num == 0:
                nums[i] = -1
        
        # array_two = [0] * n
        # array_two[0] = nums[0]
        # for i in range(1, n):
        #     array_two[i] = array_two[i-1] + nums[i]
        
        hashmap = {}
        max_len = 0
        running_sum = 0
        for index in range(n):
            num = nums[index]
            running_sum += num

            if running_sum == 0:
                max_len = max(max_len, index+1)
                continue
            
            if running_sum not in hashmap:
                hashmap[running_sum] = index
            else:
                first_occurence = hashmap[running_sum]
                length = index - first_occurence
                max_len = max(max_len, length)
        
        return max_len