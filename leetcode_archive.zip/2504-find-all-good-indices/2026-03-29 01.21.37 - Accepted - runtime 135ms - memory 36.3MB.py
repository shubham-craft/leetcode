class Solution:
    def goodIndices(self, nums: List[int], k: int) -> List[int]:
        n = len(nums)
        downhill = [1] * n
        uphill = [1] * n

        for i in range(1, n):
            if nums[i] <= nums[i-1]:
                downhill[i] = downhill[i-1] + 1
        
        for i in range(n-2, -1, -1):
            if nums[i] <= nums[i+1]:
                uphill[i] = uphill[i+1] + 1
        
        res = []
        for i in range(k, n-k):
            if downhill[i-1] >= k and uphill[i+1] >= k:
                res.append(i)
        
        return res