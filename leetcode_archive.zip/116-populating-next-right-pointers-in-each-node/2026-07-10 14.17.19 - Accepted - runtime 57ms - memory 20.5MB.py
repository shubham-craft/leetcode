"""
# Definition for a Node.
class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next
"""

class Solution:
    def connect(self, root: 'Optional[Node]') -> 'Optional[Node]':
        if not root:
            return None
        queue = deque([root])
        while queue:
            queue_len = len(queue)
            inner_queue = deque()
            for _ in range(queue_len):
                node = queue.popleft()
                if queue:
                    node.next = queue[0]
                else:
                    node.next = None

                if node.left:
                    inner_queue.append(node.left)
                    # queue.append(node.left)
                if node.right:
                    inner_queue.append(node.right)
                    # queue.append(node.right)
            
            if len(inner_queue) != 0:
                queue = inner_queue
        
        return root