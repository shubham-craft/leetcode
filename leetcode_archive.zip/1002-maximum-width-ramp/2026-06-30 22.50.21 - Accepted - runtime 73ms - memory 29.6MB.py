class Solution:
    def maxWidthRamp(self, nums: List[int]) -> int:
        max_width = 0
        n = len(nums)
        stack = []
        for idx, num in enumerate(nums):
            if not stack:
                stack.append((idx, num))
            else:
                top_number = stack[-1][1]
                if num <= top_number:
                    stack.append((idx,num))
        # print(stack)
        i = n-1
        while i >= 0:
            if not stack:
                break

            top_number = stack[-1][1]
            top_number_index = stack[-1][0]

            if nums[i] >= top_number:
                width = i - top_number_index
                max_width = max(max_width, width)
                stack.pop()
            else:
                i -= 1

        
        return max_width