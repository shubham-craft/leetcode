class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        n = len(s)
        max_length = 0
        left = 0
        hashmap = {}
        for right in range(n):
            char = s[right]
            if char in hashmap:
                hashmap[char] += 1
                while hashmap[char] != 1:
                    left_char = s[left]
                    hashmap[left_char] -= 1
                    if hashmap[left_char] == 0:
                        del hashmap[left_char]
                    left += 1
            else:
                hashmap[char] = 1
            
            length = right - left + 1
            max_length = max(max_length, length)

        return max_length