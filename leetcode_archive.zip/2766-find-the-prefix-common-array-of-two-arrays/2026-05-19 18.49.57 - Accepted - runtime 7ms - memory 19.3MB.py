class Solution:
    def findThePrefixCommonArray(self, A: List[int], B: List[int]) -> List[int]:
        n = len(A)
        prefix_array = [0] * n
        reference_array = [0] * (n+1)
        prefix_sum = 0
        for i in range(n):
            num1 = A[i]
            num2 = B[i]
            
            reference_array[num1] += 1
            if reference_array[num1] == 2:
                prefix_sum += 1
            
            reference_array[num2] += 1
            if reference_array[num2] == 2:
                prefix_sum += 1

            prefix_array[i] = prefix_sum
    
        return prefix_array