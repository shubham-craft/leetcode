class Solution:
    def frequencySort(self, s: str) -> str:
        n = len(s)
        hashmap = {}
        for char in s:
            if char in hashmap:
                hashmap[char] += 1
            else:
                hashmap[char] = 1
        
        buckets = [[] for i in range(n + 1)]
        
        for char, count in hashmap.items():
            buckets[count].append(char)
        
        # res = ""
        res = []
        for i in range(n, -1, -1):
            if len(buckets[i]) != 0:
                for c in buckets[i]:
                    # res += (i * c) #THIS IS TOO SLOW
                    '''When you write res += (i * c), Python cannot just append characters to the end of res.Instead, it has to create a brand new string copy in memory, copy the old text over, and add the new text.Inside a loop, this turns an (O(N)) time operation into a slow (O(N^2)) time operation because of constant data copying.'''

                    res.append(i * c)
        
        # return res
        return "".join(res)