class Solution:
    def validateBinaryTreeNodes(self, n: int, leftChild: list[int], rightChild: list[int]) -> bool:
        graph = {i : [] for i in range(n)}
        incoming = [0] * n
        for i in range(n):
            left_child = leftChild[i]
            right_child = rightChild[i]

            if left_child != -1:
                graph[i].append(left_child)
                incoming[left_child] += 1
            if right_child != -1:
                graph[i].append(right_child)
                incoming[right_child] += 1
        
        root = -1
        for node in range(n):
            if incoming[node] == 0:
                if root == -1:
                    root = node
                else:
                    return False
        
        if root == -1:
            return False
        
        def detect_cycle(node):
            if node in visited:
                return True
            visited.add(node)
            for nei in graph[node]:
                if detect_cycle(nei):
                    return True
            
            return False
        
        visited = set()
        is_cycle = detect_cycle(root)
        if is_cycle:
            return False
        
        if len(visited) != n:
            return False
        
        return True