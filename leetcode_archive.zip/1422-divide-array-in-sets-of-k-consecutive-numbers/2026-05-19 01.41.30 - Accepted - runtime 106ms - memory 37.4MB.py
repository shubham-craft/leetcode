class Solution:
    def isPossibleDivide(self, nums: List[int], k: int) -> bool:
        n = len(nums)
        rem = n % k
        if rem > 0:
            return False

        hashmap = {}
        for num in nums:
            if num not in hashmap:
                hashmap[num] = 1
            else:
                hashmap[num] += 1

        unique_nums = sorted(hashmap.keys())
        for num in unique_nums:
            count = hashmap[num]
            if count == 0:
                continue
            for i in range(1, k):
                consecutive_numbers = num + (i)
                if consecutive_numbers not in hashmap or hashmap[consecutive_numbers] < count:
                    return False
                
                hashmap[consecutive_numbers] -= count
        
        return True