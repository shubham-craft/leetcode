# class Solution:
#     def largestInteger(self, nums: List[int], k: int) -> int:
#         n = len(nums)
#         result = [0] * 51
#         def calculate_freq(start, end):
#             hashmap = {}
#             for i in range(start, end+1):
#                 num = nums[i]
#                 if num not in hashmap:
#                     hashmap[num] = 1
#                 else:
#                     hashmap[num] += 1
            
#             for num, freq in hashmap.items():
#                 result[num] += freq
        
#         for number in range(n-k):
#             strt = number
#             endd = number+k
#             calculate_freq(strt, endd)
        
#         print(hashmap)
class Solution:
    def largestInteger(self, nums: List[int], k: int) -> int:
        n = len(nums)
        result = [0] * 51
        if n <= k:
            for number in nums:
                result[number] = 1
        else:
            for i in range(n-k+1):
                hashset = set()
                for right in range(i, i+k):
                    num = nums[right]
            
                    if num not in hashset:
                        hashset.add(num)

                # print(hashmap)
                for number in hashset:
                    result[number] += 1        
        
        # print(result)
        for number in range(50, -1, -1):
            if result[number] == 1:
                return number
        
        return -1