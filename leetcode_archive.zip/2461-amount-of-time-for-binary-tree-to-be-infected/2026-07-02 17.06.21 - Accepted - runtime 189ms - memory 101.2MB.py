# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def amountOfTime(self, root: Optional[TreeNode], start: int) -> int:
        graph = defaultdict(list)
        def postOrder(root):
            if not root:
                return None

            if root.left:
                graph[root.val].append(root.left.val)
                graph[root.left.val].append(root.val)

            if root.right:
                graph[root.val].append(root.right.val)
                graph[root.right.val].append(root.val)

            postOrder(root.left)
            postOrder(root.right)
        
        postOrder(root)
        
        queue = deque()
        queue.append(start)
        visited = set()
        visited.add(start)
        time = -1
        while queue:
            queue_len = len(queue)
            for _ in range(queue_len):
                node = queue.popleft()

                for nei in graph[node]:
                    if nei == None:
                        continue
                    if nei in visited:
                        continue
                    
                    queue.append(nei)
                    visited.add(nei)
            
            time += 1
        
        return time