class Solution:
    def minAddToMakeValid(self, s: str) -> int:
        n = len(s)
        stack = []
        extra = 0
        for char in s:
            if char == '(':
                stack.append('(')
            else:
                if stack:
                    stack.pop()
                else:
                    extra += 1
        
        return extra + len(stack)