class Solution:
    def shortestBeautifulSubstring(self, s: str, k: int) -> str:
        n = len(s)
        smallest_len = float('inf')
        beautiful = ''
        count_so_far = 0
        left = 0
        for right in range(n):
            char = s[right]
            if char == '1':
                count_so_far += 1
            
            while count_so_far == k:
                length = right-left+1
                if length < smallest_len:
                    beautiful = s[left:right+1]
                    smallest_len = length
                elif length == smallest_len:
                    string = s[left:right+1]
                    if string < beautiful:
                        beautiful = s[left:right+1]
                
                left_char = s[left]
                if left_char == '1':
                    count_so_far -= 1
                    
                left += 1
        
        return beautiful