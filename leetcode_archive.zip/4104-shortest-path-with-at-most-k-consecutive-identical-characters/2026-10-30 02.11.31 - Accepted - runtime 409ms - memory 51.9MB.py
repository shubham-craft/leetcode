class Solution:
    def shortestPath(self, n: int, edges: List[List[int]], labels: str, k: int) -> int:
        if n == 1:
            return 0
        graph = {i : [] for i in range(n)}
        for u,v,weight in edges:
            graph[u].append((v, weight))
        
        min_heap = [(0,0,1)]
        weight_mat = {}

        while min_heap:
            weight, node, streak = heapq.heappop(min_heap)
            if node == (n-1):
                return weight
            
            if weight > weight_mat.get((node, streak), float('inf')):
                continue
            
            for nei, w in graph[node]:
                nei_label = labels[nei]
                curr_label = labels[node]
                if nei_label == curr_label:
                    new_streak = streak + 1
                else:
                    new_streak = 1
                
                if new_streak > k:
                    continue
                
                new_weight = weight + w

                if new_weight < weight_mat.get((nei, new_streak), float('inf')):
                    weight_mat[(nei, new_streak)] = new_weight
                    heapq.heappush(min_heap, (new_weight, nei, new_streak))
        
        return -1
