class Solution:
    def minOperations(self, nums: list[int], x: int) -> int:
        n = len(nums)
        summ = sum(nums)
        our_target = summ - x #basically we want to leave 'x' in the edges. so our target is to form 'summ - x' somewhere in the middle.

        max_window_length = float('-inf')
        running_sum = 0
        left = 0
        for right in range(n):
            num = nums[right]
            running_sum += num

            while running_sum > our_target and left <= right:
                running_sum -= nums[left]
                left += 1

            if running_sum == our_target:
                length = right - left + 1
                max_window_length = max(max_window_length, length)

        if max_window_length == float('-inf'):
            return -1
        
        return n - max_window_length