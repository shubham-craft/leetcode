class Solution:
    def getAncestors(self, n: int, edges: list[list[int]]) -> list[list[int]]:
        graph = {i : [] for i in range(n)}
        incoming = [0] * n
        for from_node, to_node in edges:
            graph[to_node].append(from_node)
            incoming[to_node] += 1

        def dfs(node):
            for nei in graph[node]:
                if nei in dependency:
                    continue
                dependency.add(nei)
                dfs(nei)

        result = [[]] * n
        for node in range(n):
            if incoming[node] != 0:
                dependency = set()
                dfs(node)
                result[node] = list(dependency)
                result[node].sort()
        
        return result