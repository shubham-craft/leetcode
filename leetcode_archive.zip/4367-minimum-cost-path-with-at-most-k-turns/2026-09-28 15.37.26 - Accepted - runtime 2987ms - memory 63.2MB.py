class Solution:
    def minCost(self, grid: list[list[int]], k: int) -> int:
        rows = len(grid)
        cols = len(grid[0])
        #right=0, down=1, left=2, up=3
        directions = [(1,0,0), (0,-1,1), (-1,0,2), (0,1,3)]
        start_cost = grid[0][0]
        min_heap = [(start_cost,0,0,k,-1)]
        cost_mat = {}
        while min_heap:
            cost, row, col, turns_left, curr_direction = heapq.heappop(min_heap)

            if row == rows-1 and col == cols-1:
                return cost
            
            if cost > cost_mat.get((row, col, turns_left, curr_direction), float('inf')):
                continue
            
            for dir_row, dir_col, direction in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if new_row < 0 or new_row >= rows or new_col < 0 or new_col >= cols:
                    continue
                
                if curr_direction != -1 and curr_direction != direction:
                    new_turns_left = turns_left - 1
                    if new_turns_left < 0:
                        continue
                else:
                    new_turns_left = turns_left
                
                new_direction = direction

                new_cost = cost + grid[new_row][new_col]

                if new_cost < cost_mat.get((new_row, new_col, new_turns_left, new_direction), float('inf')):
                    cost_mat[(new_row, new_col, new_turns_left, new_direction)] = new_cost
                    heapq.heappush(min_heap, (new_cost, new_row, new_col, new_turns_left, new_direction))
        
        return -1