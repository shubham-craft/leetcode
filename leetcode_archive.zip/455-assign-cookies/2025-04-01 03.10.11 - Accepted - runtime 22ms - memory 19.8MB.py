class Solution:
    def findContentChildren(self, g: List[int], s: List[int]) -> int:
        l = r = 0
        g.sort()
        s.sort()
        # if len(s) == 0:
        #     return 0
        while l < len(g) and r < len(s):
            if s[r] >= g[l]:
                l += 1
            r += 1
        
        print(l)
        return l

        