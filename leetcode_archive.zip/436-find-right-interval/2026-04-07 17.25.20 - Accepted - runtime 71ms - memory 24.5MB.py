class Solution:
    def findRightInterval(self, intervals: List[List[int]]) -> List[int]:
        # interval_start = []
        # result = []

        # for index, value in enumerate(intervals):
        #     start_interval = value[0]
        #     interval_start.append([start_interval, index])   

        # interval_start.sort(key=lambda x: x[0])
        # # print(interval_start) 
        
        # for i in range(len(intervals)):
        #     interval = intervals[i]
        #     end = interval[1]

        #     ans = -1
        #     left = 0
        #     right = len(interval_start) - 1
        #     while left <= right:
        #         mid = left + (right-left)//2
        #         if interval_start[mid][0] >= end:
        #             ans = interval_start[mid][1]
        #             right = mid-1
        #         else:
        #             left = mid+1
            
        #     result.append(ans)

        # return result

        #THIS IS GOOD, BUT LEARN TO WRITE A CLEAN CODE
        starts = [(interval[0], i) for i, interval in enumerate(intervals)]
        starts.sort()
        result =[]
        
        for interval in intervals:
            end_time = interval[1]

            left = 0
            right = len(starts) - 1
            ans = -1
            while left <= right:
                mid = left + (right-left)//2
                if starts[mid][0] >= end_time:
                    ans = starts[mid][1]
                    right = mid-1
                else:
                    left = mid+1

            result.append(ans)
                
        return result