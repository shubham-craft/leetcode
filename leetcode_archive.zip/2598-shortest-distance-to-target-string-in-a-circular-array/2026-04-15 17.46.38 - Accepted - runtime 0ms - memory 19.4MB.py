class Solution:
    def closestTarget(self, words: List[str], target: str, startIndex: int) -> int:
        n = len(words)
        min_dist = float('inf')
        for i in range(n):
            if words[i] == target:
                straight_dist = abs(startIndex - i)
                wrap_dist = n - straight_dist

                shortest_dist_from_i = min(straight_dist, wrap_dist)

                min_dist = min(min_dist, shortest_dist_from_i)
        
        return min_dist if min_dist != float('inf') else -1