class Solution:
    def numOfSubarrays(self, arr: List[int], k: int, threshold: int) -> int:
        n = len(arr)
        left = 0
        total = 0
        summ = 0
        for right in range(n):
            summ += arr[right]

            if right-left+1 == k:
                average = summ / k
                if average >= threshold:
                    total += 1
                summ -= arr[left]
                left += 1            
        
        return total