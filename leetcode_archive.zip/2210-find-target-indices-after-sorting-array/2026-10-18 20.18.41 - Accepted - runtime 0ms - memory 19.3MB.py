class Solution:
    def targetIndices(self, nums: list[int], target: int) -> list[int]:
        n = len(nums)
        numbers_less_than_target = 0
        numbers_equal_to_target = 0
        for index in range(n):
            number = nums[index]
            if number < target:
                numbers_less_than_target += 1
            elif number == target:
                numbers_equal_to_target += 1
        
        result = []
        for index in range(numbers_less_than_target, numbers_less_than_target+numbers_equal_to_target):
            result.append(index)
        
        return result