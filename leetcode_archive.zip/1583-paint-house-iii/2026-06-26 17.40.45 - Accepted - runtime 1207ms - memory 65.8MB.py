class Solution:
    def minCost(self, houses: List[int], cost: List[List[int]], m: int, n: int, target: int) -> int:
        memo = {}
        def dfs(prev_color, curr_idx, rem_target):
            if rem_target < 0:
                return float('inf')
            if curr_idx == m:
                if rem_target == 0:
                    return 0
                else:
                    return float('inf')
            if (prev_color, curr_idx, rem_target) in memo:
                return memo[(prev_color, curr_idx, rem_target)]
            
            res = float('inf')
            if houses[curr_idx] != 0:
                curr_color = houses[curr_idx]
                if prev_color == curr_color:
                    new_target = rem_target
                else:
                    new_target = rem_target - 1
                
                color_cost = 0 + dfs(curr_color, curr_idx+1, new_target)
                res = min(res, color_cost)
            else:
                for color in range(n):
                    curr_color = color+1
                    curr_cost = cost[curr_idx][color]

                    if prev_color == curr_color:
                        new_target = rem_target
                    else:
                        new_target = rem_target - 1
                    
                    color_cost = curr_cost + dfs(curr_color, curr_idx+1, new_target)
                    res = min(res, color_cost)

            memo[(prev_color, curr_idx, rem_target)] = res
            return memo[(prev_color, curr_idx, rem_target)]
        
        ans = dfs(-1, 0, target)
        return ans if ans != float('inf') else -1