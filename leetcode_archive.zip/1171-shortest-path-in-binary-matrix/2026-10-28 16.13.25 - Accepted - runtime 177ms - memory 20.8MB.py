class Solution:
    def shortestPathBinaryMatrix(self, grid: List[List[int]]) -> int:
        rows = len(grid)
        cols = len(grid[0])
        if grid[0][0] != 0 or grid[rows-1][cols-1] != 0:
            return -1
        
        directions = [(0,1), (0,-1), (1,0), (-1,0), (1,1), (1,-1), (-1,1), (-1,-1)]
        queue = deque()
        queue.append((0,0,1))
        visited = set()
        visited.add((0,0))

        while queue:
            row, col, moves = queue.popleft()
            if row == rows-1 and col == cols-1:
                return moves
            
            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if new_row < 0 or new_row >= rows or new_col < 0 or new_col >= cols:
                    continue
                if grid[new_row][new_col] == 1:
                    continue
                if (new_row, new_col) in visited:
                    continue
                
                queue.append((new_row, new_col, moves+1))
                visited.add((new_row, new_col))
        
        return -1