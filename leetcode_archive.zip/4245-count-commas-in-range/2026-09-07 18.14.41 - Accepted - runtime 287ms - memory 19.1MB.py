class Solution:
    def countCommas(self, n: int) -> int:
        if n < 1000:
            return 0
            
        comma_count = 0
        if n >= 1000:
            for i in range(1000, n+1):
                comma_count += 1

        return comma_count