class Solution:
    def minMoves2(self, nums: list[int]) -> int:
        n = len(nums)
        nums.sort()
        mid_index = n//2
        median = nums[mid_index]
        moves = 0
        for num in nums:
            moves += abs(num - median)
        
        return moves