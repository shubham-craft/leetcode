class Solution:
    def lastStoneWeight(self, stones: List[int]) -> int:
        max_heap = []
        for stone in stones:
            heapq.heappush(max_heap, -stone)
        
        while max_heap and len(max_heap) > 1:
            largest_stone = -heapq.heappop(max_heap)
            second_largest_stone = -heapq.heappop(max_heap)
            weight_diff = largest_stone - second_largest_stone
            if weight_diff == 0:
                continue
            else:
                heapq.heappush(max_heap, -weight_diff)
            
        if len(max_heap) == 1:
            return -max_heap[0]
        else:
            return 0