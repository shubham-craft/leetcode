# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def verticalTraversal(self, root: Optional[TreeNode]) -> List[List[int]]:
        if root is None:
            return []
        
        queue = deque()
        queue.append((root, 0, 0))
        nodes = []

        while queue:
            curr_node, row, col = queue.popleft()
            if curr_node.left:
                queue.append((curr_node.left, row+1, col-1))
            if curr_node.right:
                queue.append((curr_node.right, row+1, col+1))
            nodes.append((col, row, curr_node.val))
        
        # print(nodes)
        nodes.sort()
        dictionary = {}
        for col, row, value in nodes:
            if col not in dictionary:
                dictionary[col] = []
            dictionary[col].append(value)
        
        # print(dictionary)

        sorted_cols = sorted(dictionary.keys())

        final_result = []
        for col in sorted_cols:
            final_result.append(dictionary[col])
        
        # print(final_result)
        return final_result

            
        

            

        