# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def hasPathSum(self, root: Optional[TreeNode], targetSum: int) -> bool:
        def dfs(node, target_val):
            if not node:
                return False
            
            target_val -= node.val

            if target_val == 0:
                if not node.left and not node.right:
                    return True
            
            left_path_sum = dfs(node.left, target_val)
            right_path_sum = dfs(node.right, target_val)

            return left_path_sum or right_path_sum

        if dfs(root, targetSum):
            return True
        return False