class Solution:
    def countElements(self, nums: List[int]) -> int:
        count = 0
        minn = min(nums)
        maxx = max(nums)
        for num in nums:
            if num > minn and num < maxx:
                count += 1
        
        return count