class Solution:
    def findMaxForm(self, strs: List[str], m: int, n: int) -> int:
        length = len(strs)
        memo = {}
        def dfs(i, rem_m, rem_n):
            if rem_m < 0 or rem_n < 0:
                return float('-inf')
            if i == length:
                return 0
            if (i, rem_m, rem_n) in memo:
                return memo[(i, rem_m, rem_n)]
            
            # res = float('-inf')
            curr = strs[i]
            new_rem_m = rem_m
            new_rem_n = rem_n
            for numbers in curr:
                if numbers == '0':
                    new_rem_m -= 1
                if numbers == '1':
                    new_rem_n -= 1
            take = 1 + dfs(i+1, new_rem_m, new_rem_n)
            skip = 0 + dfs(i+1, rem_m, rem_n)
            res = max(take, skip)

            memo[(i, rem_m, rem_n)] = res
            return memo[(i, rem_m, rem_n)]
        
        return dfs(0, m, n)