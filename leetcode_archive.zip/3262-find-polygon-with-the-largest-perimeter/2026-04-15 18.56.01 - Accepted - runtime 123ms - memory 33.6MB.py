class Solution:
    def largestPerimeter(self, nums: List[int]) -> int:
        nums.sort()
        n = len(nums)
        max_peri = -1
        for i in range(n-1, 1, -1):
            left = i-1
            summ = 0
            largest_side = nums[i]
            while left != -1:
                summ += nums[left]
                if summ > largest_side:
                    peri = summ + largest_side
                    max_peri = max(max_peri, peri)
                
                left -= 1
            
            if max_peri != -1:
                return max_peri
        
        return max_peri