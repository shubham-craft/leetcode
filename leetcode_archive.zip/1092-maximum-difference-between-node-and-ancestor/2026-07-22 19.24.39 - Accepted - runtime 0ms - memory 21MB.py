# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def maxAncestorDiff(self, root: Optional[TreeNode]) -> int:
        self.max_diff = 0
        if not root:
            return 0
        def max_diff(node, maxx, minn):
            if not node:
                return
            
            value = node.val
            maxx = max(maxx, value)
            minn = min(minn, value)
            diff = maxx - minn
            self.max_diff = max(self.max_diff, diff)

            max_diff(node.left, maxx, minn)
            max_diff(node.right, maxx, minn)
        
        max_diff(root, float('-inf'), float('inf'))
        return self.max_diff