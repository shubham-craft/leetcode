class Solution:
    def getKth(self, lo: int, hi: int, k: int) -> int:
        memo = {}
        def dfs(number):
            if number == 1:
                return 0
            if number in memo:
                return memo[number]
            
            if number % 2 != 0:
                res = 1 + dfs((number * 3) + 1)
            else:
                res = 1 + dfs(number // 2)
            
            memo[number] = res
            return memo[number]
        
        ans = [(0, 0)] * (hi - lo + 1)

        for i, num in enumerate(range(lo, hi + 1)):
            ans[i] = (dfs(num), num)
        
        ans.sort()
        return ans[k-1][1]