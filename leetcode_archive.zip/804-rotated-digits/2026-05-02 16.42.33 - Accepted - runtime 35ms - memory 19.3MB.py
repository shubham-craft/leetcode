class Solution:
    def rotatedDigits(self, n: int) -> int:
        count = 0
        for i in range(1, n+1):
            str_digit = str(i)
            new_str_digit = ""
            for stri in str_digit:
                if stri in ('3','4','7'):
                    count -= 1
                    break
                if stri == '2':
                    new_str_digit += '5'
                elif stri == '5':
                    new_str_digit += '2'
                elif stri == '6':
                    new_str_digit += '9'
                elif stri == '9':
                    new_str_digit += '6'
                else:
                    new_str_digit += stri
            
            if new_str_digit != str_digit:
                count += 1
        
        return count