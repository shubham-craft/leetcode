class Solution:
    def countPartitions(self, nums: List[int]) -> int:
        n = len(nums)
        right_sum = sum(nums)
        partition = 0
        left_sum = 0
        for i in range(n-1):
            num = nums[i]
            left_sum += num
            right_sum -= num
            if abs(right_sum - left_sum) % 2 == 0:
                partition += 1
        
        return partition
