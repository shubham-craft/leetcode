class Solution:
    def isSubsequence(self, s: str, t: str) -> bool:
        s_len = len(s)
        t_len = len(t)
        if t_len < s_len:
            return False
        memo = {}
        def dp(i, j):
            if i == s_len:
                return True
            if j == t_len:
                return False
            if (i,j) in memo:
                return memo[(i,j)]
            
            res = False
            if s[i] == t[j]:
                res = dp(i+1, j+1)
            else:
                res = dp(i, j+1)
            
            memo[(i, j)] = res
            return memo[(i,j)]
        
        return dp(0,0)