class Solution:
    def findMaxConsecutiveOnes(self, nums: List[int]) -> int:
        left = curr = 0
        for right in range(len(nums)):
            if nums[right] != 0:
                curr = max(curr, right-left+1)
            else:
                left = right+1

        print(curr)
        return curr