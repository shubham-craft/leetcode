class Solution:
    def getLongestSubsequence(self, words: List[str], groups: List[int]) -> List[str]:
        n = len(groups)
        res = []
        prev = -1
        for i in range(n):
            if groups[i] != prev:
                res.append(words[i])
                prev = groups[i]
        
        return res