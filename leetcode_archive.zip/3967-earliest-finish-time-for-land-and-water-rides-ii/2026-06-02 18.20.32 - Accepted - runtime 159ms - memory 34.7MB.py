class Solution:
    def earliestFinishTime(self, landStartTime: List[int], landDuration: List[int], waterStartTime: List[int], waterDuration: List[int]) -> int:
        land = len(landStartTime)
        water = len(waterStartTime)

        minLandEnd = float('inf')
        for i in range(land):
            landStart = landStartTime[i]
            landDur = landDuration[i]
            landEnd = landStart + landDur
            minLandEnd = min(minLandEnd, landEnd)
    
        minLandWaterEnd = float('inf')
        for j in range(water):
            waterStart = waterStartTime[j]
            waterDur = waterDuration[j]
            actualWaterStart = max(waterStart, minLandEnd)
            waterEnd = actualWaterStart + waterDur
            minLandWaterEnd = min(minLandWaterEnd, waterEnd)
        
        minWaterEnd = float('inf')
        for i in range(water):
            waterStart = waterStartTime[i]
            waterDur = waterDuration[i]
            waterEnd = waterStart + waterDur
            minWaterEnd = min(minWaterEnd, waterEnd)
        
        minWaterLandEnd = float('inf')
        for j in range(land):
            landStart = landStartTime[j]
            landDur = landDuration[j]
            actualLandStart = max(landStart, minWaterEnd)
            landEnd = actualLandStart + landDur
            minWaterLandEnd = min(minWaterLandEnd, landEnd)
    
        return min(minLandWaterEnd, minWaterLandEnd)