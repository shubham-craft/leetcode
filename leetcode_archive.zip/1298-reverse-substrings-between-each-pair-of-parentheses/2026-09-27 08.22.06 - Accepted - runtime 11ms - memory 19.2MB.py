class Solution:
    def reverseParentheses(self, s: str) -> str:
        n = len(s)
        stack = []
        for i in range(n):
            char = s[i]
            if char == ')':
                inner_stack = []
                while stack[-1] != '(':
                    popped_char = stack.pop()
                    inner_stack.append(popped_char)
                stack.pop()
                stack.extend(inner_stack)
            else:
                stack.append(char)
        
        return "".join(stack)