class Solution:
    def areNumbersAscending(self, s: str) -> bool:
        prev_max = -1
        strings = s.split(' ')
        for stri in strings:
            if stri.isdigit():
                num = int(stri)
                if num <= prev_max:
                    return False
                
                prev_max = num
        
        return True