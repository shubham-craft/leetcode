class Solution:
    def orangesRotting(self, grid: list[list[int]]) -> int:
        rows = len(grid)
        cols = len(grid[0])
        directions = [(0,1), (0,-1), (1,0), (-1,0)]
        queue = deque()
        fresh_oranges = 0
        for row in range(rows):
            for col in range(cols):
                if grid[row][col] == 2:
                    queue.append((0, row, col))
                elif grid[row][col] == 1:
                    fresh_oranges += 1
        
        minutes_elapsed = 0 
        while queue:
            time, row, col = queue.popleft()
            minutes_elapsed = time
            
            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col
            
                if 0 <= new_row < rows and 0 <= new_col < cols and grid[new_row][new_col] == 1:
                    queue.append((time+1, new_row, new_col))
                    grid[new_row][new_col] = 2
                    fresh_oranges -= 1
        
        return minutes_elapsed if fresh_oranges == 0 else -1