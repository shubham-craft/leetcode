# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def findSecondMinimumValue(self, root: Optional[TreeNode]) -> int:
        self.min = root.val
        self.second_min = float('inf')
        def traversal(node):
            if not node:
                return
            
            traversal(node.left)
            traversal(node.right)
            
            if node.val > self.min and node.val < self.second_min:
                self.second_min = node.val
        
        traversal(root)
        
        return self.second_min if self.second_min != float('inf') else -1