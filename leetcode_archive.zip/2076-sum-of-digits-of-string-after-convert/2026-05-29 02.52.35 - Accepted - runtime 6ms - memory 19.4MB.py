class Solution:
    def getLucky(self, s: str, k: int) -> int:
        str_num = ''
        for char in s:
            place = ord(char) - ord('a') + 1
            str_num += str(place)
        
        num = int(str_num)
        while k > 0:
            summ = 0
            while num > 0:
                summ += num % 10
                num //= 10
            num = summ
            k -= 1
        
        return summ