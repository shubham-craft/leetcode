class Solution:
    def isGood(self, nums: List[int]) -> bool:
        n = len(nums)
        arr = [0] * (n)
        # nums.sort()
        max_element = max(nums)
        if n != (max_element+1):
            return False
        
        # seen = set()
        for num in nums:
            arr[num] += 1
        
        for i in range(1, len(arr)-1):
            if arr[i] == 0 or arr[i] > 1:
                return False
        
        if arr[-1] != 2:
            return False
        
        return True