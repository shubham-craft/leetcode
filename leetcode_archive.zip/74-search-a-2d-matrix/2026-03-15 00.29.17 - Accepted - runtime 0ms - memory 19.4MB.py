class Solution:
    def searchMatrix(self, matrix: List[List[int]], target: int) -> bool:
        rows = len(matrix)
        cols = len(matrix[0])
        total_items = rows * cols
        # print(rows, cols, total_items)
        
        start = 0
        end = total_items - 1
        while start <= end:
            mid = start + (end - start)//2
            mid_row = mid // cols
            mid_col = mid % cols
            if matrix[mid_row][mid_col] == target:
                return True
            elif matrix[mid_row][mid_col] > target:
                end = mid - 1
            else:
                start = mid + 1
        
        return False