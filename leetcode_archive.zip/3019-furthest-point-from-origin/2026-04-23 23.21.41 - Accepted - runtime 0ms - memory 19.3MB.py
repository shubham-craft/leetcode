class Solution:
    def furthestDistanceFromOrigin(self, moves: str) -> int:
        L_count = 0
        R_count = 0
        default = 0
        for move in moves:
            if move == 'L':
                L_count += 1
            elif move == 'R':
                R_count += 1
            else:
                default += 1
        
        furthest_dist = 0
        difference = abs(L_count - R_count)
        if L_count > R_count:
            furthest_dist = difference + default
        else:
            furthest_dist = difference + default
        
        return furthest_dist
        # memo = {}
        # def dfs(i):
        #     if i == len(moves):
        #         return 0
        #     if i in memo:
        #         return memo[i]
            
        #     if moves[i] == 'L':
        #         res = -1 + dfs(i+1)
        #     elif moves[i] == 'R':
        #         res = 1 + dfs(i+1)
        #     else:
        #         take_L = -1 + dfs(i+1)
        #         take_R = 1 + dfs(i+1)
        #         res = max(abs(take_L), abs(take_R))
            
        #     memo[i] = res
        #     return memo[i]
        
        # max_dist = dfs(0)
        # return abs(max_dist)