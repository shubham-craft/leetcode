class Solution:
    def maxDistance(self, nums1: List[int], nums2: List[int]) -> int:
        max_dist = 0
        pointer1, pointer2 = 0, 0
        while pointer1 < len(nums1) and pointer2 < len(nums2):
            if nums1[pointer1] <= nums2[pointer2]:
                dist = pointer2 - pointer1
                max_dist = max(max_dist, dist)
                pointer2 += 1
            else:
                pointer1 += 1

                if pointer1 > pointer2:
                    pointer2 = pointer1
    
        return max_dist