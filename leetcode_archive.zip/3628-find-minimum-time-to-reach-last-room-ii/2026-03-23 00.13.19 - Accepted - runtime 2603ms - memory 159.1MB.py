class Solution:
    def minTimeToReach(self, moveTime: List[List[int]]) -> int:
        if not moveTime:
            return 0
        rows = len(moveTime)
        cols = len(moveTime[0])

        best_time_dict = {}
        best_time_dict[(0, 0, 1)] = 0

        min_heap = []
        heapq.heappush(min_heap, (0,0,0,1))

        directions = [(1,0),(-1,0), (0,1), (0,-1)]

        while min_heap:
            time, row, col, next_step_cost = heapq.heappop(min_heap)
            if row == rows-1 and col == cols-1:
                return time
            
            if time > best_time_dict.get((row, col, next_step_cost), float('inf')):
                continue
            
            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if 0 <= new_row < rows and 0 <= new_col < cols:
                    new_time = max(time, moveTime[new_row][new_col])

                    new_time_with_step_cost = new_time + next_step_cost

                    new_step_cost = 3 - next_step_cost

                    if new_time_with_step_cost < best_time_dict.get((new_row, new_col, new_step_cost), float('inf')):
                        best_time_dict[(new_row, new_col, new_step_cost)] = new_time_with_step_cost
                        heapq.heappush(min_heap, (new_time_with_step_cost, new_row, new_col, new_step_cost))