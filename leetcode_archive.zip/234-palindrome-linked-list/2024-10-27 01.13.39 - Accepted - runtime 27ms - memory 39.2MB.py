# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def isPalindrome(self, head: Optional[ListNode]) -> bool:
        head_lst = []
        # print(head)
        while head is not None:
            head_lst.append(head.val)
            head = head.next

        rev_head_lst = head_lst[::-1]
        # print(head_lst)
        # print(rev_head_lst)
        if head_lst == rev_head_lst:
            return True
        else:
            return False
        