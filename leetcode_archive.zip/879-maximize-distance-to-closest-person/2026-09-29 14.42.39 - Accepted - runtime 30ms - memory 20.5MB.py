class Solution:
    def maxDistToClosest(self, seats: list[int]) -> int:
        n = len(seats)
        straight = [float('inf')] * n
        for i in range(n):
            if seats[i] == 1:
                straight[i] = 0
            else:
                if i > 0 and straight[i-1] != float('inf'):
                    straight[i] = straight[i-1] + 1
        
        reverse = [float('inf')] * n
        for i in range(n-1, -1, -1):
            if seats[i] == 1:
                reverse[i] = 0
            else:
                if (i+1) < n and reverse[i+1] != float('inf'):
                    reverse[i] = reverse[i+1] + 1
        
        max_distance = 0
        for i in range(n):
            max_distance = max(max_distance, min(straight[i], reverse[i]))
        
        return max_distance