class Solution:
    def twoEditWords(self, queries: List[str], dictionary: List[str]) -> List[str]:
        # result = []
        # for query in queries:
        #     for dictt in dictionary:
        #         edit = 0
        #         for i in range(len(query)):
        #             if query[i] != dictt[i]:
        #                 edit += 1
                
        #         if edit < 3:
        #             result.append(query)
        #             break
        
        # return result

        '''
        THIS IS NICE, BUT YOU CAN USE ZIP
        ALSO CAN BREAK EARLY AS SOON AS THE edits == 3
        THIS WILL SAVE SOME TIME
        '''
        result = []
        for query in queries:
            for dict_word in dictionary:
                edits = 0
                for q_char, d_char in zip(query, dict_word):
                    if q_char != d_char:
                        edits += 1
                    
                    if edits == 3:
                        break
                    
                if edits <= 2:
                    result.append(query)
                    break
        
        return result