class Solution:
    def minMoves(self, classroom: List[str], energy: int) -> int:
        rows = len(classroom)
        cols = len(classroom[0])
        litter_ids = {}

        for row in range(rows):
            for col in range(cols):
                if classroom[row][col] == 'S':
                    start_row = row
                    start_col = col
                
                if classroom[row][col] == 'L':
                    litter_ids[(row, col)] = len(litter_ids)
        
        total_litter = len(litter_ids)
        target_litter = (1 << total_litter) - 1
        min_heap = []
        heapq.heappush(min_heap, (0, start_row, start_col, energy, 0))

        energy_mat = {}

        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        while min_heap:
            moves, row, col, energy_left, litter_mask = heapq.heappop(min_heap)
            if litter_mask == target_litter:
                return moves
            
            if energy_left <= energy_mat.get((row, col, litter_mask), float('-inf')):
                continue
            
            energy_mat[(row, col, litter_mask)] = energy_left
            
            if energy_left == 0:
                continue

            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if 0 > new_row or new_row >= rows or 0 > new_col or new_col >= cols:
                    continue
                
                if classroom[new_row][new_col] == 'X':
                    continue
                
                new_litter_mask = litter_mask
                if classroom[new_row][new_col] == 'S' or classroom[new_row][new_col] == '.':
                    new_energy = energy_left - 1
                elif classroom[new_row][new_col] == 'L':
                    new_energy = energy_left - 1
                    litter_id = litter_ids[(new_row, new_col)] 
                    new_litter_mask = litter_mask | (1 << litter_id)
                else:
                    new_energy = energy
                
                new_moves = moves + 1
                
                if new_energy > energy_mat.get((new_row, new_col, new_litter_mask), float('-inf')):
                    # energy_mat[(new_row, new_col, new_litter_mask)] = new_energy

                    heapq.heappush(min_heap, (new_moves, new_row, new_col, new_energy, new_litter_mask))
        
        return -1