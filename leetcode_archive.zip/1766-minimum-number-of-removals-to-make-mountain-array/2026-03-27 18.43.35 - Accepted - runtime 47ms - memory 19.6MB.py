class Solution:
    def minimumMountainRemovals(self, nums: List[int]) -> int:
        n = len(nums)

        def getLISandLDS(listt):
            sub_list = []
            lis = [1] * len(listt)

            def binarySearch(subsequence, target):
                left = 0
                right = len(subsequence) - 1
                while left <= right:
                    mid = left + (right-left)//2

                    if subsequence[mid] == target:
                        return mid
                    elif subsequence[mid] < target:
                        left = mid+1
                    else:
                        right = mid-1
            
                return left

            for i in range(len(listt)):
                num = listt[i]
            
                idx = binarySearch(sub_list, num)

                if idx == len(sub_list):
                    sub_list.append(num)
                else:
                    sub_list[idx] = num
            
                lis[i] = idx+1
            
            return lis
    
        lis = getLISandLDS(nums)
        lds = getLISandLDS(nums[::-1])[::-1] 
        max_mountain_array = 0

        for i in range(1, n-1):
            if lis[i] > 1 and lds[i] > 1:
                mountain_array = lis[i] + lds[i] - 1
                max_mountain_array = max(max_mountain_array, mountain_array)
        
        return n - max_mountain_array