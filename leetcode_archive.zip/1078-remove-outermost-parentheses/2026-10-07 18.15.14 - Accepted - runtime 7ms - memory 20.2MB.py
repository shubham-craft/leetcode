class Solution:
    def removeOuterParentheses(self, s: str) -> str:
        n = len(s)
        stack = []
        removed_indexes = set()
        depth = 0
        for index, char in enumerate(s):
            if char == '(':
                stack.append(index)
                depth += 1
            else:
                popped_index = stack.pop()
                depth -= 1
                if depth == 0:
                    removed_indexes.add(popped_index)
                    removed_indexes.add(index)
        
        new_parantheses = []
        for index, char in enumerate(s):
            if index in removed_indexes:
                continue
            
            new_parantheses.append(char)
        
        return "".join(new_parantheses)