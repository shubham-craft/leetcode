class Solution:
    def findChampion(self, n: int, edges: List[List[int]]) -> int:
        indegree = [0] * n
        champion = -1
        for a, b in edges:
            indegree[b] += 1
        
        print(indegree)
        for index, degree in enumerate(indegree):
            if degree == 0 and champion == -1:
                champion = index
            elif degree == 0 and champion != -1:
                return -1
        
        return champion