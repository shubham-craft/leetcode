class Solution:
    def findNumbers(self, nums: List[int]) -> int:
        # count = 0
        # for num in nums:
        #     temp = num
        #     length = 0
        #     while temp > 0:
        #         temp = temp // 10
        #         length += 1

        #     if length % 2 == 0:
        #         count += 1
        
        # return count

        '''
        THIS IS GOOD. BUT USING O(N^2).
        CAN SOLVE IT USING LOGARITHMS AS WELL.
        '''
        count = 0
        for num in nums:
        #log10(0) is mathematically UNDEFINED and will crash
        #So, MUST mention this in an interview if you use logs.
            if num == 0:
                length = 1
            else:
                length = int(math.log10(num)) + 1
                
            if length % 2 == 0:
                count += 1
                
        return count