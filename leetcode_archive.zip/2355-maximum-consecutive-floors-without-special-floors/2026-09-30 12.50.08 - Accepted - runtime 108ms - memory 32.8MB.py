class Solution:
    def maxConsecutive(self, bottom: int, top: int, special: list[int]) -> int:
        special.sort()
        n = len(special)
        max_consecutive = special[0] - bottom
        for i in range(1, n):
            consecutive = special[i] - special[i-1] - 1
            max_consecutive = max(max_consecutive, consecutive)
        
        max_consecutive = max(max_consecutive, top - special[-1])
    
        return max_consecutive