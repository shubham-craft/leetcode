# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def buildTree(self, preorder: List[int], inorder: List[int]) -> Optional[TreeNode]:
        if not preorder and not inorder:
            return None
        
        root_val = preorder[0]
        root = TreeNode(root_val)

        inorder_root_idx = inorder.index(root_val)

        left_inorder = inorder[:inorder_root_idx]
        right_inorder = inorder[inorder_root_idx+1:]

        preorder_left_len = len(left_inorder)
        left_preorder = preorder[1:preorder_left_len+1]
        right_preorder = preorder[preorder_left_len+1:]

        root.left = self.buildTree(left_preorder, left_inorder)
        root.right = self.buildTree(right_preorder, right_inorder)
    
        return root