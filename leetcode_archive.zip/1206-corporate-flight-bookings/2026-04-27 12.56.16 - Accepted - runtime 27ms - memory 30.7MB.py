class Solution:
    def corpFlightBookings(self, bookings: List[List[int]], n: int) -> List[int]:
        diff = [0] * (n+2)
        for booking in bookings:
            first = booking[0]
            last = booking[1]
            seats = booking[2]
            diff[first] += seats
            if last+2 < n+2:
                diff[last+1] -= seats
            # print(diff)
        for i in range(n+1):
            diff[i] += diff[i-1]
        
        return diff[1:n+1]