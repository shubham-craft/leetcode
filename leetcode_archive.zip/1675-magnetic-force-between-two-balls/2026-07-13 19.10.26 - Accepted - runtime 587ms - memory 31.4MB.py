class Solution:
    def maxDistance(self, position: List[int], m: int) -> int:
        position.sort()
        n = len(position)

        def can_place(dist):
            last_placed = position[0]
            balls_placed = 1
            for i in range(1, n):
                curr_position = position[i]
                distance = curr_position - last_placed
                if distance >= dist:
                    balls_placed += 1
                    last_placed = curr_position
            
            return balls_placed >= m
        
        left = 1
        right = max(position) - min(position)
        ans = -1
        while left <= right:
            mid = left + (right-left)//2
            if can_place(mid):
                ans = mid
                left = mid+1
            else:
                right = mid-1
        
        return ans