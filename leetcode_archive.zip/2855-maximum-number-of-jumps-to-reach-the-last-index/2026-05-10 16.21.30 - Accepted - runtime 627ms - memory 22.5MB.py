class Solution:
    def maximumJumps(self, nums: List[int], target: int) -> int:
        n = len(nums)
        memo = {}
        def dfs(idx):
            if idx == n-1:
                return 0
            if idx > n-1:
                return float('-inf')
            if idx in memo:
                return memo[idx]
            
            res = float('-inf')
            for next_idx in range(idx+1, n):
                if -target <= nums[next_idx] - nums[idx] <= target:
                    jump = 1 + dfs(next_idx)

                    res = max(res, jump)

            memo[idx] = res
            return memo[idx]
        
        ans = dfs(0)
        return ans if ans != float('-inf')  else -1