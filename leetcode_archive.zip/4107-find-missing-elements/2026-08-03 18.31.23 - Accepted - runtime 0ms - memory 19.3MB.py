class Solution:
    def findMissingElements(self, nums: List[int]) -> List[int]:
        n = len(nums)
        min_num = float('inf')
        max_num = float('-inf')
        arr = [0] * 101
        for i in range(n):
            num = nums[i]
            min_num = min(min_num, num)
            max_num = max(max_num, num)
            arr[num] = 1 
        
        res = []
        for i in range(min_num, max_num+1):
            if arr[i] == 0:
                res.append(i)
        
        return res