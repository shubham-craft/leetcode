# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def pseudoPalindromicPaths (self, root: Optional[TreeNode]) -> int:
        def traversal(node, mask):
            if not node:
                return 0
            
            mask = mask ^ (1 << node.val)

            if not node.left and not node.right:
                if mask & (mask-1) == 0:
                    return 1
                else:
                    return 0
            
            left_result = traversal(node.left, mask)
            right_result = traversal(node.right, mask)

            return left_result + right_result
        
        return traversal(root, 0)