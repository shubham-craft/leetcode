class Solution:
    def isValid(self, s: str) -> bool:
        mapping = {')':'(', ']':'[', '}':'{'}
        stack = []
        for bracket in s:
            if bracket in mapping:
                if not stack:
                    return False
                if stack[-1] != mapping[bracket]:
                    return False
                stack.pop()
            else:
                stack.append(bracket)
        
        return len(stack) == 0