class Solution:
    def arrayPairSum(self, nums: List[int]) -> int:
        nums.sort()
        n = len(nums)
        summ = 0
        left = 0
        for i in range(1, n, 2):
            min_num = min(nums[i-1], nums[i])
            summ += min_num
        
        return summ