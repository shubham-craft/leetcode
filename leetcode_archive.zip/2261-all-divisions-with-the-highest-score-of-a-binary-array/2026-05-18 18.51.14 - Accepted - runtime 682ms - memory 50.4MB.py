class Solution:
    def maxScoreIndices(self, nums: List[int]) -> List[int]:
        n = len(nums)
        zero_prefix = [0] * (n+2)
        one_suffix = [0] * (n+2)
        for i in range(n):
            if nums[i] == 0:
                zero_prefix[i+1] = zero_prefix[i] + 1
            else:
                zero_prefix[i+1] = zero_prefix[i]
        
        for i in range(n-1, -1, -1):
            if nums[i] == 1:
                one_suffix[i+1] = one_suffix[i+2] + 1
            else:
                one_suffix[i+1] = one_suffix[i+2]
        
        hashmap = {}
        for i in range(n+1):
            curr_max = zero_prefix[i] + one_suffix[i+1]
            if curr_max not in hashmap:
                hashmap[curr_max] = [i]
            else:
                hashmap[curr_max].append(i)

        # print(zero_prefix)
        # print(one_suffix)
        max_hashmap = max(hashmap)
        return hashmap[max_hashmap]