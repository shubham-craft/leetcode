class Solution:
    def reachableNodes(self, n: int, edges: List[List[int]], restricted: List[int]) -> int:
        restricted_set = set(restricted)
        graph = {i : [] for i in range(n)}
        for a,b in edges:
            if a not in restricted_set and b not in restricted_set:
                graph[a].append(b)
                graph[b].append(a)
        
        visited = set()
        def dfs(node):
            visited.add(node)
            for nei in graph[node]:
                if nei not in visited:
                    dfs(nei)
        
        dfs(0)

        return len(visited)