# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def zigzagLevelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        result = []
        if not root:
            return result
        
        queue = deque([root])
        level = 0
        while queue:
            queue_len = len(queue)
            inner_level = []
            for _ in range(queue_len):
                node = queue.popleft()
                inner_level.append(node.val)

                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
                
            if level % 2 != 0:
                inner_level = inner_level[::-1]
            
            result.append(inner_level)

            level += 1
        
        return result