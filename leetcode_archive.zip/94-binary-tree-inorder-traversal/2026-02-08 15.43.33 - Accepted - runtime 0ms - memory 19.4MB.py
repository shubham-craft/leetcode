# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def inorderTraversal(self, root: Optional[TreeNode]) -> List[int]:
        result = []

        def inOrderTraverse(root):
            if not root:
                return

            inOrderTraverse(root.left)
            result.append(root.val)
            inOrderTraverse(root.right)

        inOrderTraverse(root)
        return result