class Solution:
    def isPrefixString(self, s: str, words: List[str]) -> bool:
        length_s = len(s)
        index = 0
        string = ''
        for word in words:
            length_word = len(word)
            if index + length_word > length_s:
                break

            string += word
            
            index += length_word
        
        return string == s