class Solution:
    def minimumObstacles(self, grid: List[List[int]]) -> int:
        rows = len(grid)
        cols = len(grid[0]) 

        obstacles_removed = 0
        if grid[0][0] == 1:
            obstacles_removed += 1
        min_obstacle_remover = {}
        min_obstacle_remover[(0,0)] = obstacles_removed

        min_heap =[(obstacles_removed, 0, 0)]

        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        while min_heap:
            obstacles_removed, row, col = heapq.heappop(min_heap)
            if row == rows-1 and col == cols-1:
                return obstacles_removed

            if obstacles_removed > min_obstacle_remover.get((row,col), float('inf')):
                continue
            
            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if 0 <= new_row < rows and 0 <= new_col < cols:
                    updated_obstacles_removed = obstacles_removed + grid[new_row][new_col]
                
                    if updated_obstacles_removed < min_obstacle_remover.get((new_row,new_col), float('inf')):
                        min_obstacle_remover[(new_row, new_col)] = updated_obstacles_removed
                        heapq.heappush(min_heap, (updated_obstacles_removed, new_row, new_col))