class Solution:
    def maxDistance(self, grid: List[List[int]]) -> int:
        rows = len(grid)
        cols = len(grid[0])
        queue = deque()
        directions = [(0,1), (0,-1), (1,0), (-1,0)]
        # dist_mat = [[-1] * cols for _ in range(rows)]

        for row in range(rows):
            for col in range(cols):
                if grid[row][col] == 1:
                    queue.append((row, col, 0))
                    grid[row][col] = -1
        
        max_dist = -1
        while queue:
            row, col, dist = queue.popleft()
            max_dist = max(max_dist, dist)

            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if 0 <= new_row < rows and 0 <= new_col < cols and grid[new_row][new_col] != -1:
                    new_dist = dist + 1
                    queue.append((new_row, new_col, new_dist))
                    grid[new_row][new_col] = -1
        
        return max_dist if max_dist != 0 else -1