class Solution:
    def minimumOperations(self, nums: list[int]) -> int:
        min_heap = []
        for num in nums:
            if num == 0:
                continue
            heapq.heappush(min_heap, num)
        
        operations = 0
        if not min_heap:
            return operations 
            
        to_remove = min_heap[0]
        while min_heap:
            while min_heap and to_remove == min_heap[0]:
                popped_number = heapq.heappop(min_heap)
            
            operations += 1
            if min_heap:
                to_remove = min_heap[0]
        
        return operations
