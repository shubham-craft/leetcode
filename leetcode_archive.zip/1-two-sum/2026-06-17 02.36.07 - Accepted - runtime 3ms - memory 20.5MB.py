class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        hashmap = {}
        n = len(nums)
        for idx, num in enumerate(nums):
            diff = target - num
            if diff in hashmap:
                return [hashmap[diff], idx]
            else:
                hashmap[num] = idx