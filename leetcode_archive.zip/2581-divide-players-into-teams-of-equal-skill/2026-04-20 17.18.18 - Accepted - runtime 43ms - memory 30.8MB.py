class Solution:
    def dividePlayers(self, skill: List[int]) -> int:
        if len(skill) < 2:
            return -1
        skill.sort()
        prev_summ = skill[0] + skill[len(skill) - 1]
        total_chem_summ = skill[0] * skill[len(skill) - 1]
        left = 1
        right = len(skill) - 2
        while left < right:
            summ = skill[left] + skill[right]
            if summ != prev_summ:
                return -1
            
            curr_chem_summ = skill[left] * skill[right]
            total_chem_summ += curr_chem_summ

            left += 1
            right -= 1
        
        return total_chem_summ