class UnionFind:
    def __init__(self, n):
        self.parent = [i for i in range(n)]
        self.rank = [1] * n
        self.size = [1] * n
        self.components = n
    
    def find(self, x):
        if x == self.parent[x]:
            return x
        
        self.parent[x] = self.find(self.parent[x])

        return self.parent[x]
    
    def union(self, x, y):
        x_root = self.find(x)
        y_root = self.find(y)
        
        if x_root == y_root:
            return False
        
        if self.rank[x_root] > self.rank[y_root]:
            self.parent[y_root] = x_root
            self.size[x_root] += self.size[y_root]
        elif self.rank[y_root] > self.rank[x_root]:
            self.parent[x_root] = y_root
            self.size[y_root] += self.size[x_root]
        else:
            self.parent[y_root] = x_root
            self.rank[x_root] += 1
            self.size[x_root] += self.size[y_root]
        
        self.components -= 1

        return True

class Solution:
    def smallestEquivalentString(self, s1: str, s2: str, baseStr: str) -> str:
        n = len(s1)
        uf = UnionFind(26)

        for i in range(n):
            s1_char = s1[i]
            s2_char = s2[i]
            s1_char_ord = ord(s1_char) - ord('a')
            s2_char_ord = ord(s2_char) - ord('a')
            uf.union(s1_char_ord, s2_char_ord)            
        
        hashmap = {}
        for ordinal in range(26):
            root_ordinal = uf.find(ordinal)
            if root_ordinal not in hashmap:
                hashmap[root_ordinal] = ordinal
            else:
                hashmap[root_ordinal] = min(hashmap[root_ordinal], ordinal)

        result = []
        for i in range(len(baseStr)):
            base_char = baseStr[i]
            ord_base_char = ord(base_char) - ord('a')
            root = uf.find(ord_base_char)

            smallest_char_in_group_ord = hashmap[root]

            smallest_char_in_group = chr((smallest_char_in_group_ord) + ord('a'))
            result.append(smallest_char_in_group)

        return "".join(result)