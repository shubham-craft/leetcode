class Solution:
    def minimumDistance(self, nums: List[int]) -> int:
        hashmap = {}
        min_dist = float('inf')
        for index, num in  enumerate(nums):
            if num not in hashmap:
                hashmap[num] = [index]
            elif len(hashmap[num]) == 1:
                hashmap[num].append(index)
            else:
                older_index = hashmap[num][0]
                latest_index = index
                dist = 2 * (latest_index - older_index)
                min_dist = min(min_dist, dist)

                hashmap[num][0] = hashmap[num][1]
                hashmap[num][1] = index
        
        return min_dist if min_dist != float('inf') else -1