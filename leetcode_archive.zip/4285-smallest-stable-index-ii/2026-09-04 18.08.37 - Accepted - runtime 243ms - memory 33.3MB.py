class Solution:
    def firstStableIndex(self, nums: list[int], k: int) -> int:
        n = len(nums)
        pref_max = [float('-inf')] * n
        pref_max[0] = nums[0]
        post_min = [float('inf')] * n
        post_min[-1] = nums[-1]

        for i in range(1, n):
            number = nums[i]
            pref_max[i] = max(pref_max[i-1], number)
        
        for i in range(n-2, -1, -1):
            number = nums[i]
            post_min[i] = min(post_min[i+1], number)
        
        for i in range(n):
            maxx = pref_max[i]
            minn = post_min[i]
            if maxx - minn <= k:
                return i
        
        return -1