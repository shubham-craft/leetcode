class Solution:
    def splitArray(self, nums: List[int], k: int) -> int:
        n = len(nums)
        maxx = max(nums)
        summ = sum(nums)
        def is_partition_possible(partition_sum):
            partition = 1
            curr_sum = 0
            for num in nums:
                curr_sum += num
                if curr_sum > partition_sum:
                    partition += 1
                    curr_sum = num
            
            return partition <= k
        
        left = maxx
        right = summ
        ans = summ
        while left <= right:
            mid = left + (right - left) // 2
            if is_partition_possible(mid):
                ans = mid
                right = mid-1
            else:
                left = mid+1
        
        return ans