class Solution:
    def isHappy(self, n: int) -> bool:
        seen = set()
        seen.add(n)
        summ = 0
        while len(seen) > 0:
            while n > 0:
                number = n % 10
                summ += number ** 2
                n //= 10
            if summ == 1:
                return True
            if summ in seen:
                return False
            n = summ
            seen.add(summ)
            summ = 0
