class Solution:
    def nextGreaterElements(self, nums: list[int]) -> list[int]:
        n = len(nums)
        hashmap = {}
        stack = []
        for i in range(2*n):
            actual_index = i % n
            curr_number = nums[actual_index]
            while stack and stack[-1][1] < curr_number:
                popped_index, popped_num = stack.pop()
                hashmap[popped_index] = curr_number
            
            stack.append((actual_index, curr_number))
        
        result = [-1] * n
        for index in range(n):
            if index in hashmap:
                result[index] = hashmap[index]
        
        return result