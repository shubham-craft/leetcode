class Solution:
    def minimumEffort(self, tasks: List[List[int]]) -> int:
        n = len(tasks)
        # sorted_min = sorted(tasks, key=lambda x: x[1], reverse=True)
        # start = sorted_min[0][1]
        # remaining = sorted_min[0][1] - sorted_min[0][0]
        diff = [[0,0]] * n

        for i in range(n):
            actual = tasks[i][0]
            min_need = tasks[i][1]
            difference = min_need - actual
            
            diff[i] = [i,difference]
        
        # print(diff)
        sorted_diff = sorted(diff, key=lambda x: x[1], reverse=True)
        # print(sorted_diff)
        # print(tasks)

        start_index = sorted_diff[0][0]
        start = tasks[start_index][1]
        remaining = tasks[start_index][1] - tasks[start_index][0]
        for i in range(1, n):
            index = sorted_diff[i][0]
            need = tasks[index][1]
            to_use = tasks[index][0]

            if need > remaining:
                start += need - remaining
                remaining = need - to_use
            else:
                remaining -= to_use
                   
        # print(diff)
        # print(tasks)
        # print(sorted_diff)
        # print(remaining)
        
        return start