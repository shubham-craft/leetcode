class Solution:
    def numSubarraysWithSum(self, nums: list[int], goal: int) -> int:
        n = len(nums)
        hashmap = {0:1}
        running_sum = 0
        count = 0
        for num in nums:
            running_sum += num
            target_sum = running_sum - goal
            if target_sum in hashmap:
                frequency = hashmap[target_sum]
                count += frequency
            
            if running_sum not in hashmap:
                hashmap[running_sum] = 1
            else:
                hashmap[running_sum] += 1
        
        return count