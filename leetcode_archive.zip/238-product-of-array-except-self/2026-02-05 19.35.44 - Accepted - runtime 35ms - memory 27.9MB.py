class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        n = len(nums)
        prefix_pass = [1] * n
        postfix_pass = [1] * n
        result = [1] * n

        pre_prod = 1
        for i in range(1, n):
            pre_prod *=  nums[i-1]
            prefix_pass[i] = pre_prod
        
        post_prod = 1
        for i in range(n-2, -1, -1):
            post_prod *= nums[i+1]
            postfix_pass[i] = post_prod
        
        for i in range(len(result)):
            result[i] = prefix_pass[i] * postfix_pass[i]
        
        return result