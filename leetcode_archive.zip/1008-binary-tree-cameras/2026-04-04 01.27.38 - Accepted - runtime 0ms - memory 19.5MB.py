# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def minCameraCover(self, root: Optional[TreeNode]) -> int:
        #2 -> child saying parent that i am not covered
        #1 -> child saying parent that i have a camera, so even you're covered
        #0 -> child saying parent that at least i am covered
        self.cameras = 0
        def dfs(root):
            if not root:
                return 0

            dfs_left = dfs(root.left)
            dfs_right = dfs(root.right)            

            if dfs_left == 2 or dfs_right == 2:
                self.cameras += 1
                return 1
            elif dfs_left == 1 or dfs_right == 1:
                return 0
            else:
                return 2
        
        final_root_status = dfs(root)
        if final_root_status == 2:
            return self.cameras + 1
        else:
            return self.cameras