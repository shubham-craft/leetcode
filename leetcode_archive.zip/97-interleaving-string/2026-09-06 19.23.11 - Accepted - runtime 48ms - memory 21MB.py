class Solution:
    def isInterleave(self, s1: str, s2: str, s3: str) -> bool:
        s1_len = len(s1)
        s2_len = len(s2)
        s3_len = len(s3)
        if s1_len + s2_len != s3_len:
            return False
        memo = {}

        def dp(i, j):
            if i > s1_len or j > s2_len or i+j > s3_len:
                return False

            if i+j == s3_len:
                return True
            
            if (i, j) in memo:
                return memo[(i,j)]
            
            take_s1 = False
            take_s2 = False
            if i < s1_len and s1[i] == s3[i+j]:
                take_s1 = dp(i+1, j)
            if j < s2_len and s2[j] == s3[i+j]:
                take_s2 = dp(i, j+1)
            
            res = take_s1 or take_s2
            memo[(i, j)] = res
            return memo[(i,j)]
        
        return dp(0,0)