# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def findMode(self, root: Optional[TreeNode]) -> List[int]:
        hashmap = {}
        self.max_appearance = 0
        def find_mode(node):
            if not node:
                return
            
            node_val = node.val
            if not node_val in hashmap:
                hashmap[node_val] = 1
            else:
                hashmap[node_val] += 1
            
            self.max_appearance = max(self.max_appearance, hashmap[node_val])
            
            left_tree = find_mode(node.left)
            right_tree = find_mode(node.right)
        
        find_mode(root)
        # print(self.max_appearance)
        # print(hashmap)
        res = []
        for num, appearance in hashmap.items():
            if appearance == self.max_appearance:
                res.append(num)
        
        return res