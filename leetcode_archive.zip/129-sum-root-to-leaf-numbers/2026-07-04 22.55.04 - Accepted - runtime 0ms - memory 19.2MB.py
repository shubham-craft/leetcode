# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def sumNumbers(self, root: Optional[TreeNode]) -> int:
        res = []
        def dfs(node, number):
            if not node:
                return
            
            number += str(node.val)

            if not node.left and not node.right:
                res.append(number)
                return
            
            if node.left:
                dfs(node.left, number)
            if node.right:
                dfs(node.right, number)
        
        dfs(root, "")
        # print(res)
        total_sum = 0
        for num in res:
            total_sum += int(num)
        
        return total_sum