class Solution:
    def largestPerimeter(self, nums: List[int]) -> int:
        nums.sort()
        n = len(nums)
        max_perimeter = 0
        for i in range(n-1, 1, -1):
            third_side = nums[i]
            second_side = nums[i-1]
            first_side = nums[i-2]
            if first_side + second_side > third_side:
                perimeter = first_side + second_side + third_side
                max_perimeter = max(max_perimeter, perimeter)
                return max_perimeter
        
        return max_perimeter