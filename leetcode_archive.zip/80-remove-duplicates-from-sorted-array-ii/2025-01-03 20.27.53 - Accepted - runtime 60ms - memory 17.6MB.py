class Solution:
    def removeDuplicates(self, nums: List[int]) -> int:
        k = 0
        s = {}
        element = 0
        for i in nums:           
            if i in s:
                s[i] += 1
                if s[i] > 2:
                    continue
                else:
                    nums[element] = i
                    k += 1
                    element += 1
                    
            else:
                s[i] = 1
                nums[element] = i
                k += 1
                element += 1
        
        print(nums)
        print(k)
        return k