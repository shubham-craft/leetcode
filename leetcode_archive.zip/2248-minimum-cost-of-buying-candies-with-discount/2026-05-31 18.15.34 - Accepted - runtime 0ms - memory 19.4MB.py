class Solution:
    def minimumCost(self, cost: List[int]) -> int:
        cost.sort(reverse = True)
        n = len(cost)
        min_cost = 0
        for i in range(n):
            if (i+1) % 3 == 0:
                continue
            min_cost += cost[i]
        
        return min_cost