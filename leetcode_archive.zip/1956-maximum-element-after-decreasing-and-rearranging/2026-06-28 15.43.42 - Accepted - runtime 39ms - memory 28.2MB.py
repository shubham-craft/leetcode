class Solution:
    def maximumElementAfterDecrementingAndRearranging(self, arr: List[int]) -> int:
        arr.sort()
        if arr[0] != 1:
            arr[0] = arr[0] - arr[0] + 1
        
        n = len(arr)
        max_number = arr[0]
        for i in range(1, n):
            if abs(arr[i] - arr[i-1]) > 1:
                arr[i] = arr[i-1] + 1
            max_number = max(max_number, arr[i])
        
        return max_number