class Solution:
    def minTimeToReach(self, moveTime: List[List[int]]) -> int:
        if not moveTime:
            return 0
        rows = len(moveTime)
        cols = len(moveTime[0])

        time_matrix = [[float('inf')] * cols for _ in range(rows)]
        time_matrix[0][0] = 0

        min_heap = []
        heapq.heappush(min_heap, (0,0,0))

        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        while min_heap:
            time, row, col = heapq.heappop(min_heap)
            if row == rows-1 and col == cols-1:
                return time
            
            if time > time_matrix[row][col]:
                continue
            
            for dir_row, dir_col in directions:
                new_row = dir_row + row
                new_col = dir_col + col

                if 0 <= new_row < rows and 0 <= new_col < cols:
                    new_time = max(time, moveTime[new_row][new_col])

                    time_required = new_time + 1

                    if time_required < time_matrix[new_row][new_col]:
                        time_matrix[new_row][new_col] = time_required
                        heapq.heappush(min_heap, (time_required, new_row, new_col))