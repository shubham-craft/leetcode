class Solution:
    def scoreOfParentheses(self, s: str) -> int:
        n = len(s)
        stack = []
        depth = 0
        depth_level = [0] * 25
        score_stack = []
        last_popped = -1
        for index, char in enumerate(s):
            if char == '(':
                stack.append(index)
                depth += 1
                pop = 0
            else:
                stack.pop()
                depth -= 1
                pop += 1
                if pop == 1:
                    curr_score_at_that_depth = depth_level[depth]
                    new_score_at_that_depth = curr_score_at_that_depth + 1
                    depth_level[depth] = new_score_at_that_depth
                else:
                    if depth_level[depth+1] > 0:
                        curr_score_at_that_depth = depth_level[depth+1]
                        new_score_at_that_depth = curr_score_at_that_depth * 2
                        depth_level[depth] += new_score_at_that_depth
                        depth_level[depth+1] = 0
                    else:
                        curr_score_at_that_depth = depth_level[depth]
                        new_score_at_that_depth = curr_score_at_that_depth + 1
                        depth_level[depth] = new_score_at_that_depth * 2
        
        # print(depth_level[0])
        return depth_level[0]