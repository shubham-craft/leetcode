class Solution:
    def rotate(self, nums: List[int], k: int) -> None:
        """
        Do not return anything, modify nums in-place instead.
        """
        n = len(nums)
        nums_copy = [0] * n
        for i in range(n):
            org_pos = i
            new_pos = (i+k)%n
            nums_copy[new_pos] = nums[org_pos]
        
        # nums = nums_copy
        for i in range(n):
            nums[i] = nums_copy[i]