class Solution:
    def convertTime(self, current: str, correct: str) -> int:
        correct_hours = correct[:2]
        correct_hours = int(correct_hours)
        correct_minutes = correct[3:]
        correct_minutes = int(correct_minutes)
        correct_time = (correct_hours)*60 + correct_minutes
        
        current_hours = current[:2]
        current_hours = int(current_hours)
        current_minutes = current[3:]
        current_minutes = int(current_minutes)
        current_time = (current_hours)*60 + current_minutes

        minutes = [1, 5, 15, 60]
        target_time = correct_time - current_time
        print(correct_time)
        print(current_time)
        print(target_time)

        memo = {}
        def dfs(idx, rem_time):
            if rem_time == 0:
                return 0
            if idx == len(minutes) or rem_time < 0 :
                return float('inf')
            if (idx, rem_time) in memo:
                return memo[(idx, rem_time)]
            
            skip = 0 + dfs(idx+1, rem_time)

            take = float('inf')
            if rem_time - minutes[idx] >= 0:
                take = 1 + dfs(idx, rem_time - minutes[idx])

            res = min(take, skip)

            memo[(idx, rem_time)] = res
            return memo[(idx, rem_time)]
        
        return dfs(0, target_time)