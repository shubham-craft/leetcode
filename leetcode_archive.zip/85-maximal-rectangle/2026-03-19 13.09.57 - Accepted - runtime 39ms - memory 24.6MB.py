class Solution:
    def maximalRectangle(self, matrix: List[List[str]]) -> int:
        if not matrix or not matrix[0]:
            return 0

        rows = len(matrix)
        cols = len(matrix[0])
        max_area = 0
        heights = [0] * cols

        def rectangle_area(passed_height):
            curr_rows_height = passed_height + [0]
            stack = []
            max_area_passed_height = 0
            for curr_index, curr_height in enumerate(curr_rows_height):
                while stack and curr_height < passed_height[stack[-1]]:
                    popped_index = stack.pop()
                    popped_index_height = curr_rows_height[popped_index]
                    if stack:
                        width = curr_index - stack[-1] - 1
                    else:
                        width = curr_index
                    
                    area = popped_index_height * width
                    max_area_passed_height = max(area, max_area_passed_height)

                stack.append(curr_index)
            
            return max_area_passed_height
        
        for row in matrix:
            for i in range(cols):
                if row[i] == "0":
                    heights[i] = 0
                else:
                    heights[i] += 1
            
            area_of_passed_height = rectangle_area(heights)
            max_area = max(area_of_passed_height, max_area)
        
        return max_area