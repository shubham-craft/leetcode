class UnionFind:
    def __init__(self, n):
        self.parent = [i for i in range(n)]
        self.rank = [1] * n
    
    def find(self, x):
        if self.parent[x] == x:
            return x
        
        self.parent[x] = self.find(self.parent[x])

        return self.parent[x]

    def union(self, x, y):
        x_root = self.find(x)
        y_root = self.find(y)

        if x_root == y_root:
            return False
        
        if self.rank[x_root] > self.rank[y_root]:
            self.parent[y_root] = x_root
        elif self.rank[y_root] > self.rank[x_root]:
            self.parent[x_root] = y_root
        else:
            self.parent[y_root] = x_root
            self.rank[x_root] += 1
        
        return True
    
    def ranks(self, x):
        rank = self.rank[x]
        return rank

class Solution:
    def countCompleteComponents(self, n: int, edges: List[List[int]]) -> int:
        # degree = [0] * n
        graph = {i : [] for i in range(n)}
        for a, b in edges:
            graph[a].append(b)
            graph[b].append(a)
            # degree[a] += 1
            # degree[b] += 1
        
        # print(graph)
        # print(degree)
        self.complete_components = 0
        visited = set()
        queue = deque()
        
        def bfs(node):
            queue.append(node)
            visited.add(node)
            nodes_in_group = 0
            edges_in_group = 0
            
            while queue:
                node_popped = queue.popleft()
                nodes_in_group += 1
                for nei in graph[node_popped]:
                    edges_in_group += 1
                    if nei in visited:
                        continue
                    
                    queue.append(nei)
                    visited.add(nei)

            if edges_in_group == nodes_in_group * (nodes_in_group - 1):
                self.complete_components += 1
        
        for i in range(n):
            if i not in visited:
                bfs(i)
        
        return self.complete_components