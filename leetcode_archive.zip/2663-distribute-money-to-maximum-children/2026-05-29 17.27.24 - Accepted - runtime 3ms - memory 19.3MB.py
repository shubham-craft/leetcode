class Solution:
    def distMoney(self, money: int, children: int) -> int:
        if money == 4 and children == 1:
            return -1
        if money < children:
            return -1

        possible = 0
        child_arr = [1] * children
        rem_n = money - children

        possible_div = rem_n // 7
        count = 0
        for i in range(possible_div):
            child_arr[i] += 7
            possible += 1
            rem_n -= 7
            count += 1
            if i+1 == children:
                break
        
        if rem_n == 3 and abs(children - count) == 1:
            possible -= 1
        if rem_n > 0 and child_arr[-1] == 8:
            possible -= 1
        
        return possible