class Solution:
    def longestConsecutive(self, nums: List[int]) -> int:
        n = len(nums)
        nums_set = set(nums)
        max_consecutive = 0
        for start in nums_set:
            if (start-1) not in nums_set:
                end = (start+1)
                while end in nums_set:
                    end += 1
                max_consecutive = max(max_consecutive, end-start)

        return max_consecutive