class UnionFind:
    def __init__(self, n):
        self.parent = [i for i in range(n)]
        self.rank = [1] * (n)
    
    def find(self, x):
        if self.parent[x] == x:
            return x
        
        self.parent[x] = self.find(self.parent[x])

        return self.parent[x]
    
    def union(self, x, y):
        root_x = self.find(x)
        root_y = self.find(y)

        if root_x == root_y:
            return False
        
        if self.rank[root_x] > self.rank[root_y]:
            self.parent[root_y] = root_x
        elif self.rank[root_x] < self.rank[root_y]:
            self.parent[root_x] = root_y
        else:
            self.parent[root_y] = root_x
            self.rank[root_x] += 1
        
        return True

class Solution:
    def findCircleNum(self, isConnected: List[List[int]]) -> int:
        # if not isConnected:
        #     return 0
        # rows = len(isConnected)
        # cols = len(isConnected[0])

        # graph = {i:[] for i in range(rows)}
        
        # for row in range(rows):
        #     for col in range(cols):
        #         if row == col:
        #             continue
        #         if isConnected[row][col] == 1:
        #            graph[row].append(col)
        
        # flat_list = []
        # for key, value in graph.items():
        #     for val in value:
        #         flat_list.append((key,val))
        
        # # print(graph)
        # # print(flat_list)
        # uf = UnionFind(rows)
        # for u,v in flat_list:
        #     uf.union(u,v)
        
        # provinces = set()
        # for i in range(rows):
        #     parent = uf.find(i)
        #     provinces.add(parent)
        
        # # print(provinces)
        # return len(provinces)

        # '''
        # 0,1,3,6,7,8,13
        # 2
        # 4,5,10,11
        # 9,14
        # 12
        # '''

        #THE ABOVE THING IS GOOD AS WELL
        #BUT BIT REDUNDANT
        #CAN DISCARD THE LIST (flat_list)
        #ALSO NOT NECESSARY TO BULID AN ADJACENCY LIST
        #CAN DIRECTLY LOOP THROUGH ROW AND COL
        if not isConnected:
            return 0
        rows = len(isConnected)
        cols = len(isConnected[0])
        uf = UnionFind(rows)
        
        for row in range(rows):
            for col in range(cols):
                if row == col:
                    continue
                if isConnected[row][col] == 1:
                   uf.union(row, col)
        
        provinces = set()
        for i in range(rows):
            parent = uf.find(i)
            provinces.add(parent)
        
        return len(provinces)