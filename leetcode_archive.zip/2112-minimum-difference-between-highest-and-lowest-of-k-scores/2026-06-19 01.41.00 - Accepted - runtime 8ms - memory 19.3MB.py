class Solution:
    def minimumDifference(self, nums: List[int], k: int) -> int:
        nums.sort()
        n = len(nums)
        min_diff = float('inf')
        left = 0
        for right in range(n):
            if right-left+1 == k:
                diff = nums[right] - nums[left]
                min_diff = min(min_diff, diff)
                left += 1
        
        return min_diff