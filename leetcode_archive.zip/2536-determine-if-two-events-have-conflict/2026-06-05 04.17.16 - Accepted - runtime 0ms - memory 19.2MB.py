class Solution:
    def haveConflict(self, event1: List[str], event2: List[str]) -> bool:
        event1_start_hr = int(event1[0][:2])
        event1_start_min = int(event1[0][3:])
        event1_end_hr = int(event1[1][:2])
        event1_end_min = int(event1[1][3:])

        event2_start_hr = int(event2[0][:2])
        event2_start_min = int(event2[0][3:])
        event2_end_hr = int(event2[1][:2])
        event2_end_min = int(event2[1][3:])

        if (event1_start_hr * 100) + event1_start_min <= (event2_start_hr * 100) + event2_start_min <= (event1_end_hr * 100) + event1_end_min:
            return True
        if (event1_start_hr * 100) + event1_start_min <= (event2_end_hr * 100) + event2_end_min <= (event1_end_hr * 100) + event1_end_min:
            return True
        if (event2_start_hr * 100) + event2_start_min <= (event1_start_hr * 100) + event1_start_min <= (event2_end_hr * 100) + event2_end_min:
            return True
        if (event2_start_hr * 100) + event2_start_min <= (event1_end_hr * 100) + event1_end_min <= (event2_end_hr * 100) + event2_end_min:
            return True
        
        return False

        # print(event1_start_hr)
        # print(event1_start_min)
        # print(event1_end_hr)
        # print(event1_end_min)

        # print(event2_start_hr)
        # print(event2_start_min)
        # print(event2_end_hr)
        # print(event2_end_min)

        # if event1_start_hr < event2_start_hr < event1_end_hr:
        #     return True
        # if event1_start_hr < event2_end_hr < event1_end_hr:
        #     return True
        # if event2_start_hr < event1_start_hr < event2_end_hr:
        #         return True
        # if event2_start_hr < event1_end_hr < event2_end_hr:
        #         return True
        
        # if event1_start_hr <= event2_start_hr <= event1_end_hr:
        #     if event1_start_min <= event2_start_min <= event1_end_min:
        #         return True
        # if event1_start_hr <= event2_end_hr <= event1_end_hr:
        #     if event1_start_min <= event2_end_min <= event1_end_min:
        #         return True
        # if event2_start_hr <= event1_start_hr <= event2_end_hr:
        #     if event2_start_min <= event1_start_min <= event2_end_min:
        #         return True
        # if event2_start_hr <= event1_end_hr <= event2_end_hr:
        #     if event2_start_min <= event1_end_min <= event2_end_min:
        #         return True
        #     # 
        
        # # if event1_start_hr <= event2_end_hr <= event1_end_hr:
        # #     if event1_start_min <= event2_end_min <= event1_end_min:
        # #         return True
        
        # return False