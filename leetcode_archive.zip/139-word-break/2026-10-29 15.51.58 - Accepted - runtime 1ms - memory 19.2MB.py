class Solution:
    def wordBreak(self, s: str, wordDict: list[str]) -> bool:
        n = len(s)
        word_set = set(wordDict)
        memo = {}
        def dp(curr):
            if curr == n:
                return True
            # if curr > n:
            #     return False
            '''no need of above check becaue in for loop we are doing the boundary check
            curr + word_len <= n'''

            if (curr) in memo:
                return memo[(curr)]
            
            res = False
            for word in word_set:
                word_len = len(word)
                if curr + word_len <= n and s[curr : curr + word_len] == word:
                    res = res or dp(curr+word_len)
                    '''remember the res = res or dp()
                    if you forget the res = res or
                    and just do res = dp() on every iteration
                    then it might happen that, you found true for your second word in for loop
                    but you continued with your for loop and third word return false
                    then it will overwrite the true returned by second word'''
                    if res:
                        return True
            
            memo[curr] = res
            return res
        
        return dp(0)
            
            