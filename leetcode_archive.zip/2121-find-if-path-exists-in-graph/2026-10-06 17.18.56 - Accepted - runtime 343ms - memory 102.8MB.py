class Solution:
    def validPath(self, n: int, edges: List[List[int]], source: int, destination: int) -> bool:
        graph = {i : [] for i in range(n)}
        for a, b in edges:
            graph[a].append(b)
            graph[b].append(a)
        
        queue = deque()
        queue.append(source)
        visited = set()
        visited.add(source)
        while queue:
            node = queue.popleft()
            if node == destination:
                return True
            
            for nei in graph[node]:
                if nei in visited:
                    continue
                
                queue.append(nei)
                visited.add(nei)
        
        return False