class Solution:
    def reverseDegree(self, s: str) -> int:
        n = len(s)
        rev_degree = 0
        for index in range(n):
            char = s[index]
            ord_char = ord(char) - ord('a')
            rev_ord_char = 26 - ord_char
            product = (index+1) * rev_ord_char
            rev_degree += product
        
        return rev_degree