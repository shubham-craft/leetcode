class Solution:
    def maxSlidingWindow(self, nums: List[int], k: int) -> List[int]:
        n = len(nums)
        queue = deque()
        result = []
        left = 0
        for right in range(n):
            while queue and nums[queue[-1]] < nums[right]:
                queue.pop()
            
            while queue and queue[0] < (right - k + 1):
                queue.popleft()
            
            queue.append(right)
            
            # since no left pointer so kind of tricky in when to append to result
            if (right+1) >= k:
                result.append(nums[queue[0]])

        return result