# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def minDiffInBST(self, root: TreeNode | None) -> int:
        self.min_diff = float('inf')
        def traversal(left_val, node, right_val):
            if not node:
                return 0
            
            traversal(left_val, node.left, node.val)
            left_diff = abs(node.val - left_val)
            right_diff = abs(node.val - right_val)
            self.min_diff = min(self.min_diff, left_diff, right_diff)
            traversal(node.val, node.right, right_val)
        
        traversal(float('inf'), root, float('inf'))
        return self.min_diff