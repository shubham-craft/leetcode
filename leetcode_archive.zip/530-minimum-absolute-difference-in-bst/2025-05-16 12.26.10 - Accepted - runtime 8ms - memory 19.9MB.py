# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def getMinimumDifference(self, root: Optional[TreeNode]) -> int:
        if root is None:
            return 0
        result = []
        
        def inorder(root) -> []:
            if root.left:
                inorder(root.left)
            result.append(root.val)
            if root.right:
                inorder(root.right)
            
            return result
        
        inorder_traversal = inorder(root)

        print(inorder_traversal)
        
        start = 0
        nextt = start + 1
        min_diff = float('inf')
        while nextt <= len(inorder_traversal) - 1:
            diff = inorder_traversal[nextt] - inorder_traversal[start]
            if diff < min_diff:
                min_diff = diff
            start +=1 
            nextt += 1


        return min_diff
        