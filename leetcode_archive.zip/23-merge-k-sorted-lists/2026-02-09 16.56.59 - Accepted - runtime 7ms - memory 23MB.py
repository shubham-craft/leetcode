# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def mergeKLists(self, lists: List[Optional[ListNode]]) -> Optional[ListNode]:
        min_heap = []

        for i in range(len(lists)):
            curr_list_node = lists[i]
            if curr_list_node:
                heapq.heappush(min_heap, (curr_list_node.val, i, curr_list_node))
        
        # print(min_heap)
        dummy = ListNode(0)
        tail = dummy
        while min_heap:
            smallest_node_value, i, smallest_node = heapq.heappop(min_heap)
            tail.next = smallest_node
            tail = tail.next

            if smallest_node.next:
                heapq.heappush(min_heap, (smallest_node.next.val, i, smallest_node.next))
        
        return dummy.next