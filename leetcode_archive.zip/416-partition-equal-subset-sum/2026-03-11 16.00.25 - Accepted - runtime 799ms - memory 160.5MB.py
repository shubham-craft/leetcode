class Solution:
    def canPartition(self, nums: List[int]) -> bool:
        total = sum(nums)
        if (total % 2) != 0:
            return False
        
        target = (total // 2)
        memo = {}
        def dfs(i, rem):
            if rem == 0:
                return True
            if rem < 0 or i == len(nums):
                return False
            if (i, rem) in memo:
                return memo[(i, rem)]

            # take =  dfs(i+1, rem - nums[i])
            # skip = dfs(i+1, rem)
            # res = take or skip    #thios whole thing is giving memory limit exceeded; try to write it in one line itself; Python spawned millions of useless workers and filled up the memo dictionary with useless states, crashing the memory limit 

            res = dfs(i+1, rem - nums[i]) or dfs(i+1, rem)

            memo[(i, rem)] = res
            return memo[(i, rem)]

        return dfs(0, target)