class Solution:
    def evalRPN(self, tokens: List[str]) -> int:
        stack = []
        for token in tokens:
            if token in "+-*/":
                second_num = stack.pop()
                first_num = stack.pop()
                if token == '/':
                    res = int(first_num / second_num)
                elif token == '*':
                    res = second_num * first_num
                elif token == '+':
                    res = second_num + first_num
                else:
                    res = first_num - second_num             
                stack.append(res)
            else:
                stack.append(int(token))
        
        return stack.pop()