class Solution:
    def minimumCardPickup(self, cards: list[int]) -> int:
        n = len(cards)
        min_consecutive = float('inf')
        hashmap = {}
        left = 0
        for right in range(n):
            card = cards[right]
            if card not in hashmap:
                hashmap[card] = right
            else:
                last_position_of_that_card = hashmap[card]
                consecutive = right - last_position_of_that_card + 1
                min_consecutive = min(min_consecutive, consecutive)
                hashmap[card] = right
        
        return min_consecutive if min_consecutive != float('inf') else -1