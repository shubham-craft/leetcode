class Solution:
    def miceAndCheese(self, reward1: List[int], reward2: List[int], k: int) -> int:
        n = len(reward1)
        diff = [[0,0]] * n
        for i in range(n):
            r1 = reward1[i]
            r2 = reward2[i]
            diff[i] = [r1-r2, i]
        
        diff.sort(key=lambda x: x[0], reverse=True)
        
        res = 0
        for i in range(n):
            difference = diff[i][0]
            index = diff[i][1]
            if k > 0:
                res += reward1[index]
                k -= 1
            else:
                res += reward2[index]
        
        return res