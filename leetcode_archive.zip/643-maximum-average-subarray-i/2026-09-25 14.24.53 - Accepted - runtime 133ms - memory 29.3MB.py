class Solution:
    def findMaxAverage(self, nums: list[int], k: int) -> float:
        n = len(nums)
        max_sum = float('-inf')
        summ = 0
        left = 0
        for right in range(n):
            num = nums[right]
            summ += num

            if (right-left+1) > k:
                summ -= nums[left]
                left += 1

            if (right-left+1) == k:
                max_sum = max(max_sum, summ)
        
        average = max_sum / k

        return average