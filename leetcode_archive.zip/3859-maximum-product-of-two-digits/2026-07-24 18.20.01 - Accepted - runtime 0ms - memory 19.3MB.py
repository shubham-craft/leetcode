class Solution:
    def maxProduct(self, n: int) -> int:
        numbers = []
        while n > 0:
            numbers.append(n % 10)
            n //= 10
        
        numbers.sort()
        largest = numbers[-1]
        second_largest = numbers[-2]
        max_product = largest * second_largest

        return max_product