class Solution:
    def uniformArray(self, nums1: list[int]) -> bool:
        n = len(nums1)
        pos_numbers = 0
        neg_numbers = 0
        small = float('inf')
        asc = True
        desc = True
        for num in nums1:
            if num % 2 == 0:
                pos_numbers += 1
            else:
                neg_numbers += 1
            
            small = min(small, num)
        
        if n == pos_numbers or n == neg_numbers:
            return True
        
        if small % 2 == 0:
            small_parity_even = True
        else:
            small_parity_even = False
        
        if small_parity_even:
            return False
        else:
            return True