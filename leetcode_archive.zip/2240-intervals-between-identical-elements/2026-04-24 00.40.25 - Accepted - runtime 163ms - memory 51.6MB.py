class Solution:
    def getDistances(self, arr: List[int]) -> List[int]:
        n = len(arr)
        hashmap = {}
        ans = [0] * n
        for index, num in enumerate(arr):
            if num not in hashmap:
                hashmap[num] = [index]
            else:
                hashmap[num].append(index)

        for array in hashmap.values():
            length = len(array)
            if length == 1:
                continue
            
            left_sum = 0
            total_sum = sum(array)

            for index in range(length):
                num = array[index]

                left_count = index

                right_sum = total_sum - left_sum - num
                right_count = length - index - 1 

                left_group = (left_count * num) - (left_sum)
                right_group = (right_sum) - (right_count * num)

                ans[num] = left_group + right_group

                left_sum += num   

        return ans           