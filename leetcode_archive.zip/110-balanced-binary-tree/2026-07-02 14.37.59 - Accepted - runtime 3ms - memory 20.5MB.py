# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def isBalanced(self, root: Optional[TreeNode]) -> bool:
        def dfs(root):
            if not root:
                return 0
            
            left_height = dfs(root.left)
            if left_height == -1:
                return -1

            right_height = dfs(root.right)
            if right_height == -1:
                return -1

            abs_height = abs(left_height - right_height)
            if abs_height > 1:
                return -1
            
            return 1 + max(left_height, right_height)
        
        ans = dfs(root)
        return True if ans != -1 else False
