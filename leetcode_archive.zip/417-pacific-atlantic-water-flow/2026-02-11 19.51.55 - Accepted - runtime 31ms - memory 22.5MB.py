class Solution:
    def pacificAtlantic(self, heights: List[List[int]]) -> List[List[int]]:
        if not heights:
            return []
        rows = len(heights)
        cols = len(heights[0])
        pacific_visited = set()
        atlantic_visited = set()

        def dfs(row, col, visited, previous_height):
            if row < 0 or row >= rows or col < 0 or col >= cols:
                return
            if (row,col) in visited:
                return
            new_height = heights[row][col]
            if new_height < previous_height:
                return
            
            visited.add((row,col))            
            dfs(row+1, col, visited, new_height)
            dfs(row-1, col, visited, new_height)
            dfs(row, col+1, visited, new_height)
            dfs(row, col-1, visited, new_height)
        
        for col in range(cols):
            dfs(0, col, pacific_visited, heights[0][col]) #just like walking the top part of grid --->
            dfs(rows-1, col, atlantic_visited, heights[rows-1][col]) #just like walking the bottom part of grid (like waloking on the edge of the beach) --->
        
        for row in range(rows):
                dfs(row, 0, pacific_visited, heights[row][0]) #just like walking the left part of grid (coming from left top corner to all the way down to left bottom corner)
                dfs(row, cols-1, atlantic_visited, heights[row][cols-1]) #just like walking the right part of grid (coming from right top corner to all the way down to right bottom corner)
        
        result = []
        for row in range(rows):
            for col in range(cols):
                if (row, col) in pacific_visited and (row, col) in atlantic_visited:
                    result.append([row, col])
                    
        return result