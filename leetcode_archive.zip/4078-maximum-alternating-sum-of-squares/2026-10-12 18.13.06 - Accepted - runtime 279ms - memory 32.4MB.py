class Solution:
    def maxAlternatingSum(self, nums: List[int]) -> int:
        n = len(nums)
        for i in range(n):
            num = nums[i]
            nums[i] = abs(num)
        
        nums.sort(reverse = True)
        left = 0
        right = n-1
        index = 0
        squared_diff = 0
        while left <= right:
            if index % 2 == 0:
                squared_diff += nums[left] ** 2
                left += 1
            else:
                squared_diff -= nums[right] ** 2
                right -= 1

            index += 1
        
        return squared_diff