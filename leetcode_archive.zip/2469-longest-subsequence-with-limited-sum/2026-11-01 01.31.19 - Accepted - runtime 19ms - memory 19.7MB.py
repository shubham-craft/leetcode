class Solution:
    def answerQueries(self, nums: list[int], queries: list[int]) -> list[int]:
        nums.sort()
        n = len(nums)
        prefix = [0] * n
        prefix[0] = nums[0]
        for i in range(1, n):
            prefix[i] = nums[i] + prefix[i-1]
        print(prefix)
        def completed_subsequences(max_bound):
            left = 0
            right = n-1
            ans = 0
            while left <= right:
                mid = left + (right-left)//2
                if prefix[mid] <= max_bound:
                    ans = mid+1
                    left = mid+1
                else:
                    right = mid-1
            
            return ans
        
        result = [0] * len(queries)
        for i in range(len(queries)):
            query = queries[i]
            subsequence_length = completed_subsequences(query)
            result[i] = subsequence_length
        
        return result
