class Solution:
    def minimumSum(self, num: int) -> int:
        arr = [0] * 4
        i = 0
        while num > 0:
            number = num % 10
            arr[i] += number
            num //= 10
            i += 1
        
        arr.sort()
        num1 = (arr[0] * 10) + arr[2]
        num2 = (arr[1] * 10) + arr[3]

        return num1 + num2