# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def averageOfLevels(self, root: Optional[TreeNode]) -> List[float]:
        if root is None:
            return []
        
        queue = deque()
        result = []
        queue.append(root)

        while queue:
            curr_level = len(queue)
            summ = 0
            for i in range(curr_level):
                node = queue.popleft()
                summ = summ + node.val

                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            
            result.append(summ/curr_level)
        
        # print(result)
        return result
        