class Solution:
    def dominantIndex(self, nums: List[int]) -> int:
        #FIRST SUBMISSION WAS RIGHT AS WELL
        #BUT USED SORTING IN IT
        #SIMPLE INTUITION HERE WOULD BE TO CHECK
        #IF LARGEST NUMBER >= SECOND LARGEST NUMBER
        #IF THIS IS TRUE THEN EVERYTHING ELSE WILL BE TRUE
        #THUS NO NEED OF SORTING
        n = len(nums)
        largest_index = -1
        largest_number = 0
        second_largest_index = -1
        second_largest_number = 0
        for i in range(n):
            if nums[i] > largest_number:
                second_largest_number = largest_number
                second_largest_index = largest_index
                largest_number = nums[i]
                largest_index = i
            elif second_largest_number < nums[i] < largest_number:
                second_largest_number = nums[i]
                second_largest_index = i
        
        print(largest_number)
        print(second_largest_number)
        if second_largest_number * 2 <= largest_number:
            return largest_index
        else:
            return -1