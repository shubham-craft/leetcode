class Solution:
    def minFallingPathSum(self, matrix: List[List[int]]) -> int:
        if not matrix:
            return 0
        rows = len(matrix)
        cols = len(matrix[0])
        memo = {}
        def dfs(row, col):
            # if row >= rows:
            #     return float('inf')
            if col >= cols or col < 0:
                return float('inf')
            if row == rows-1:
                return matrix[row][col]
            if (row, col) in memo:
                return memo[(row, col)]
            
            down = dfs(row+1, col)
            diagonal_left = dfs(row+1, col-1)
            diagonal_right = dfs(row+1, col+1)

            res = matrix[row][col] + min(down, diagonal_left, diagonal_right)

            memo[(row, col)] = res
            return memo[(row, col)]
        
        min_fall_path_sum = float('inf')
        for c in range(0, cols):
            min_fall_path_sum = min(min_fall_path_sum, dfs(0,c))
        
        return min_fall_path_sum