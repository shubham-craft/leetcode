class Solution:
    def reorganizeString(self, s: str) -> str:
        n = len(s)
        hashmap = {}
        for char in s:
            if char not in hashmap:
                hashmap[char] = 1
            else:
                hashmap[char] += 1
        
        max_heap = []
        for char, count in hashmap.items():
            heapq.heappush(max_heap, (-count, char))
        
        result = []
        while max_heap:
            top_count, top_char = heapq.heappop(max_heap)
            if result and result[-1] == top_char:
                if max_heap:
                    second_top_count, second_top_char = heapq.heappop(max_heap)
                    result.append(second_top_char)
                    second_top_count += 1
                    if second_top_count < 0:
                        heapq.heappush(max_heap, (second_top_count, second_top_char))
                else:
                    break
            else:
                result.append(top_char)
                top_count += 1        

            if top_count < 0:
                heapq.heappush(max_heap, (top_count, top_char))
        
        if len(result) != n:
            return ""
        
        return "".join(result)