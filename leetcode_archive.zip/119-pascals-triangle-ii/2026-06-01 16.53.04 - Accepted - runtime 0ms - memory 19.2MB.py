class Solution:
    def getRow(self, rowIndex: int) -> List[int]:
        triangle = []
        for row in range(rowIndex + 1):
            lst = [0] * (row + 1)
            for col in range(row + 1):
                if col == 0 or col == row:
                    lst[col] += 1
                else:
                    prev_row_1_col_1 = triangle[row-1][col-1]
                    prev_row_1_col = triangle[row-1][col]
                    lst[col] += prev_row_1_col_1 + prev_row_1_col
            
            triangle.append(lst)
        
        return triangle[-1]