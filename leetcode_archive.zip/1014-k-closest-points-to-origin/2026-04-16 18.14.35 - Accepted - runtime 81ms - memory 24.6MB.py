class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        max_heap = []
        x1, y1 = 0, 0
        for point in points:
            x2, y2 = point[0], point[1]
            distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
            heapq.heappush(max_heap, (-distance, point))
            if len(max_heap) > k:
                heapq.heappop(max_heap)
        
        ans = []
        for dist, point in max_heap:
            ans.append(point)
        
        return ans