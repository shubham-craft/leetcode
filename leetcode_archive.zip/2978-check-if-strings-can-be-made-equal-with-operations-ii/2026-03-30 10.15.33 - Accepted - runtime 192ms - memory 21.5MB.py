class Solution:
    def checkStrings(self, s1: str, s2: str) -> bool:
        even_hashmap = {}
        odd_hashmap = {}
        s1 = list(s1)
        s2 = list(s2)
        for i in range(len(s1)):
            if i % 2 == 0:
                if s1[i] not in even_hashmap:
                    even_hashmap[s1[i]] = 1
                else:
                    even_hashmap[s1[i]] += 1
            
            else:
                if s1[i] not in odd_hashmap:
                    odd_hashmap[s1[i]] = 1
                else:
                    odd_hashmap[s1[i]] += 1  

        for j in range(len(s2)):
            if j % 2 == 0:
                if s2[j] not in even_hashmap or even_hashmap[s2[j]] < 1:
                    return False
                else:
                    even_hashmap[s2[j]] -= 1
            
            else:
                if s2[j] not in odd_hashmap or odd_hashmap[s2[j]] < 1:
                    return False
                else:
                    odd_hashmap[s2[j]] -= 1
        
        return True