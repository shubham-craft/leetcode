class Solution:
    def uniformArray(self, nums1: list[int]) -> bool:
        n = len(nums1)
        pos_numbers = 0
        neg_numbers = 0
        for num in nums1:
            if num % 2 == 0:
                pos_numbers += 1
            else:
                neg_numbers += 1
        
        # if pos_numbers == n or neg_numbers == n or pos_numbers == neg_numbers:
        return True
        
        # return False