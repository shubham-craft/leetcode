class Solution:
    def sortArrayByParityII(self, nums: List[int]) -> List[int]:
        # n = len(nums)
        # even = []
        # odd = []
        # for num in nums:
        #     if num % 2 == 0:
        #         even.append(num)
        #     else:
        #         odd.append(num)
        
        # flag = 'even'
        # ans = []
        # while len(odd) > 0:
        #     if flag == 'even':
        #         ans.append(even.pop())
        #         flag = 'odd'
        #     else:
        #         ans.append(odd.pop())
        #         flag = 'even'
        
        # return ans

        n = len(nums)
        even_ptr = 0
        odd_ptr = 1
        while even_ptr < n and odd_ptr < n:
            if nums[even_ptr] % 2 == 0:
                even_ptr += 2
            elif nums[odd_ptr] % 2 != 0:
                odd_ptr += 2
            else:
                nums[even_ptr], nums[odd_ptr] = nums[odd_ptr], nums[even_ptr]
                even_ptr += 2
                odd_ptr += 2
        
        return nums