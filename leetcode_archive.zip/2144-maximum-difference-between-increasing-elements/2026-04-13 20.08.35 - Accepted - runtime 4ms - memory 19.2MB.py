class Solution:
    def maximumDifference(self, nums: List[int]) -> int:
        max_diff = -1
        min_seen = nums[0]
        
        for i in range(1, len(nums)):
            if nums[i] > min_seen:
                max_diff = max(max_diff, nums[i] - min_seen)
            else:
                min_seen = nums[i]
                
        return max_diff