class Solution:
    def maxProbability(self, n: int, edges: List[List[int]], succProb: List[float], start_node: int, end_node: int) -> float:
        graph = {i : [] for i in range(n)}
        for idx, edge in enumerate(edges):
            a,b = edge
            graph[a].append((b, succProb[idx]))
            graph[b].append((a, succProb[idx]))
        
        prob_mat = [float('-inf')] * n
        prob_mat[start_node] = 1
        max_heap = [(-1, start_node)]
        while max_heap:
            prob, node = heapq.heappop(max_heap)
            prob = -1 * prob
            if node == end_node:
                return prob
            
            if prob_mat[node] > prob:
                continue
            
            for nei, pr in graph[node]:
                new_prob = prob * pr

                if new_prob > prob_mat[nei]:
                    prob_mat[nei] = new_prob
                    heapq.heappush(max_heap, (-new_prob, nei))
        
        return 0