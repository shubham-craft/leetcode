class Solution:
    def maximumHappinessSum(self, happiness: List[int], k: int) -> int:
        n = len(happiness)
        happiness.sort(reverse = True)
        child_picked = 0
        max_happiness = 0
        for i in range(k):
            happy = happiness[i]
            if happy - child_picked >= 0:
                max_happiness += happy - child_picked
            
            child_picked += 1
        
        return max_happiness