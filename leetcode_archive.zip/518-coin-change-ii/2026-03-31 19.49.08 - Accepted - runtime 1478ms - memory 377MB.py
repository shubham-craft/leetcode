class Solution:
    def change(self, amount: int, coins: List[int]) -> int:
        n = len(coins)
        memo = {}
        def dfs(idx, rem_amount):
            if rem_amount == 0:
                return 1
            if idx == n or rem_amount < 0:
                return 0
            if (idx, rem_amount) in memo:
                return memo[(idx, rem_amount)]
            
            skip = dfs(idx+1, rem_amount)
            take = dfs(idx, rem_amount - coins[idx])
            res = skip + take

            memo[(idx, rem_amount)] = res
            return memo[(idx, rem_amount)]
        
        return dfs(0, amount)