class Solution:
    def rob(self, nums: List[int]) -> int:
        if len(nums) == 1:
            return nums[0]
        n = len(nums)
        memo = {}
        def dp(prev, curr, end):
            if curr >= end:
                return 0
            if (prev, curr, end) in memo:
                return memo[(prev, curr, end)]
            
            skip = 0 + dp(prev, curr+1, end)
            take = nums[curr] + dp(curr, curr+2, end)
            res = max(skip, take)

            memo[(prev, curr, end)] = res
            return memo[(prev, curr, end)]
        
        skip_first_house = dp(-1, 1, n)
        skip_last_house = dp(-1, 0, n-1)

        return max(skip_first_house, skip_last_house)