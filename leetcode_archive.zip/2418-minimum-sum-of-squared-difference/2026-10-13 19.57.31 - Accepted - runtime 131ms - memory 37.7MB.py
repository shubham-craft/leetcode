class Solution:
    def minSumSquareDiff(self, nums1: list[int], nums2: list[int], k1: int, k2: int) -> int:
        # n = len(nums1)
        # max_heap = []
        # for i in range(n):
        #     num1 = nums1[i]
        #     num2 = nums2[i]
        #     abs_diff = abs(num1 - num2)
        #     if abs_diff != 0:
        #         heapq.heappush(max_heap, -abs_diff)
        
        # total_allowed_operations = k1 + k2
        # while max_heap and total_allowed_operations > 0:
        #     max_diff = heapq.heappop(max_heap)
        #     new_reduced_diff = max_diff + 1

        #     if new_reduced_diff != 0:
        #         heapq.heappush(max_heap, new_reduced_diff)

        #     total_allowed_operations -= 1
        
        # min_squared_diff = 0
        # for abs_diff in max_heap:
        #     min_squared_diff += (abs_diff ** 2)
        
        # return min_squared_diff
        
        n = len(nums1)
        abs_diff = [0] * 100001
        max_diff = 0
        for i in range(n):
            num1 = nums1[i]
            num2 = nums2[i]
            diff = abs(num1 - num2)
            max_diff = max(max_diff, diff)
            abs_diff[diff] += 1
        
        k = k1 + k2
        for i in range(max_diff, 0, -1):
            if abs_diff[i] == 0:
                continue

            freq = abs_diff[i]
            count = min(k, freq)

            abs_diff[i] -= count
            abs_diff[i-1] += count

            k -= count

            if k == 0:
                break
        
        min_squared_diff = 0
        for i in range(max_diff, 0, -1):
            if abs_diff[i] == 0:
                continue
            
            freq = abs_diff[i]

            min_squared_diff += (freq * (i ** 2))
        
        return min_squared_diff