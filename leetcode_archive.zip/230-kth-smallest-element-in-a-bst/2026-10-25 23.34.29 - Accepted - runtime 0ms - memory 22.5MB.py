# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def kthSmallest(self, root: Optional[TreeNode], k: int) -> int:
        self.k = k
        def inorder(node):
            if not node:
                return None
            
            left_tree_val = inorder(node.left)
            if left_tree_val is not None:
                return left_tree_val

            self.k -= 1
            if self.k == 0:
                return node.val
            
            right_tree_val = inorder(node.right)
            if right_tree_val is not None:
                return right_tree_val
        
        value = inorder(root)

        return value