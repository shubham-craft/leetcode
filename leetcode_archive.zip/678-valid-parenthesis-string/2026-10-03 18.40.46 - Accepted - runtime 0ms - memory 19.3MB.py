class Solution:
    def checkValidString(self, s: str) -> bool:
        n = len(s)
        bracket_stack = []
        star_stack = []
        magic = 0
        for index, char in enumerate(s):
            if char == '(':
                bracket_stack.append(index)
            elif char == '*':
                star_stack.append(index)
            else:
                if not bracket_stack:
                    if star_stack:
                        star_stack.pop()
                    else:
                        return False
                else:
                    bracket_stack.pop()
        
        while bracket_stack:
            if not star_stack:
                return False

            last_open_bracket = bracket_stack.pop()
            last_magic_star = star_stack.pop()
            if last_magic_star < last_open_bracket:
                return False
        
        return True
            