class Solution:
    def sumOfSquares(self, nums: List[int]) -> int:
        n = len(nums)
        squared_sum = 0
        for i in range(n):
            one_based_index = i+1
            number = nums[i]
            if (n % one_based_index) == 0:
                squared_sum += (number * number)
        
        return squared_sum