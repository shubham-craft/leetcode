class Solution:
    def subarraysDivByK(self, nums: List[int], k: int) -> int:
        n = len(nums)
        running_sum = 0
        hashmap = {0: 1}
        count = 0
        for num in nums:
            running_sum += num
            target_remainder = running_sum % k

            if target_remainder in hashmap:
                frequency = hashmap[target_remainder]
                count += frequency
                
                hashmap[target_remainder] += 1
            else:
                hashmap[target_remainder] = 1
        
        return count