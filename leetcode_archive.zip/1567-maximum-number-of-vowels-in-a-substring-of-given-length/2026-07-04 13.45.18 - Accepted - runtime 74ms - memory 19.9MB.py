class Solution:
    def maxVowels(self, s: str, k: int) -> int:
        n = len(s)
        left = 0
        length = 0
        max_length = 0
        vowels = {'a','e','i','o','u'}
        for right in range(n):
            if s[right] in vowels:
                length += 1
            
            if (right - left + 1) > k:
                if s[left] in vowels:
                    length -= 1
                left += 1
            
            max_length = max(max_length, length)

        return max_length