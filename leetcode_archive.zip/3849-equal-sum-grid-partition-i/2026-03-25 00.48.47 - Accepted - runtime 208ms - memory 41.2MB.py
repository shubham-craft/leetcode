class Solution:
    def canPartitionGrid(self, grid: List[List[int]]) -> bool:
        if not grid:
            return False
        total_sum = 0
        rows = len(grid)
        cols = len(grid[0])
        for row in range(rows):
            for col in range(cols):
                total_sum += grid[row][col]
        
        if total_sum%2 != 0:
            return False
        
        partial_row_sum = 0
        partial_col_sum = 0
        
        for row in range(rows):
            for col in range(cols):
                partial_row_sum += grid[row][col]
            if partial_row_sum == total_sum//2:
                return True
        
        for col in range(cols):
            for row in range(rows):
                partial_col_sum += grid[row][col] 
            if partial_col_sum == total_sum//2:
                return True
        
        return False