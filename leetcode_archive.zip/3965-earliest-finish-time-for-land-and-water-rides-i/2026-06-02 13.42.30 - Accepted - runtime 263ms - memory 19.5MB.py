class Solution:
    def earliestFinishTime(self, landStartTime: List[int], landDuration: List[int], waterStartTime: List[int], waterDuration: List[int]) -> int:
        land = len(landStartTime)
        water = len(waterStartTime)

        minLandWaterTime = float('inf')
        for i in range(land):
            landStart = landStartTime[i]
            landDur = landDuration[i]
            totalLandTime = landStart + landDur
            for j in range(water):
                waterStart = waterStartTime[j]
                waterDur = waterDuration[j]
                actualWaterStart = max(waterStart, totalLandTime)
                
                landWaterTime = actualWaterStart + waterDur
                
                minLandWaterTime = min(minLandWaterTime, landWaterTime)

        minWaterLandTime = float('inf')
        for i in range(water):
            waterStart = waterStartTime[i]
            waterDur = waterDuration[i]
            totalWaterTime = waterStart + waterDur
            for j in range(land):
                landStart = landStartTime[j]
                landDur = landDuration[j]
                actualLandStart = max(landStart, totalWaterTime)
                
                waterLandTime = actualLandStart + landDur

                minWaterLandTime = min(minWaterLandTime, waterLandTime)
        
        min_total_time = min(minLandWaterTime, minWaterLandTime)

        return min_total_time