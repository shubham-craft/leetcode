class Solution:
    def mapWordWeights(self, words: List[str], weights: List[int]) -> str:
        res = ''
        for word in words:
            weight_sum = 0
            for letter in word:
                ord_letter = ord(letter) - ord('a')
                weight_sum += weights[ord_letter]

            result_modulo = weight_sum % 26
            rev_result_modulo = 97 + 25 - result_modulo
            char_result_modulo = chr(rev_result_modulo)
            res += char_result_modulo
    
        return res