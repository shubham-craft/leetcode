class Solution:
    def numberOfSubstrings(self, s: str) -> int:
        n = len(s)
        hashmap = {}
        total_valid = 0
        left = 0
        for right in range(n):
            char = s[right]
            if char not in hashmap:
                hashmap[char] = 1
            else:
                hashmap[char] += 1
            
            while len(hashmap) == 3:
                total_valid += n - right
                hashmap[s[left]] -= 1
                if hashmap[s[left]] == 0:
                    del hashmap[s[left]]
                left += 1
        
        return total_valid