class Solution:
    def combinationSum2(self, candidates: List[int], target: int) -> List[List[int]]:
        candidates.sort()
        res = []
        def dfs(start_i, curr, rem_sum):
            if rem_sum == 0:
                res.append(curr.copy())
                return
            if rem_sum < 0:
                return
            
            for j in range(start_i, len(candidates)):
                if j > start_i and candidates[j] == candidates[j-1]:
                    continue
                num = candidates[j]
                curr.append(num)
                dfs(j+1, curr, rem_sum-num)
                curr.pop()
    
        dfs(0, [], target)
        return res