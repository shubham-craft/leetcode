# class Solution:
#     def plusOne(self, digits: List[int]) -> List[int]:
#         leng = len(digits) - 1
#         result = 0
#         lst = []

#         for i in digits:
#             result += 10**leng * i
#             leng -= 1

#         result += 1
#         # print(result)
       
#         while result > 0:
#             rem = result % 10
#             result = result // 10
#             lst.append(rem)
        
#         # print(lst)
#         # print(lst[::-1])
#         return lst[::-1]
class Solution:
    def plusOne(self, digits: List[int]) -> List[int]:

        for i in range(len(digits) - 1, -1, -1):

            if digits[i] + 1 != 10:
                digits[i] += 1
                return digits
            
            digits[i] = 0

            if i == 0:
                return [1] + digits