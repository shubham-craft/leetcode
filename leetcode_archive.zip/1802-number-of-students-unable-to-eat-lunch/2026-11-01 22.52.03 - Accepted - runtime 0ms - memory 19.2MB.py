class Solution:
    def countStudents(self, students: list[int], sandwiches: list[int]) -> int:
        n = len(students)
        stud_hashmap = {}
        for stud in students:
            if stud not in stud_hashmap:
                stud_hashmap[stud] = 1
            else:
                stud_hashmap[stud] += 1
        
        hungry = n
        for sandwich in sandwiches:
            if sandwich in stud_hashmap and stud_hashmap[sandwich] > 0:
                stud_hashmap[sandwich] -= 1
                hungry -= 1
            else:
                break
        
        return hungry