class Solution:
    def minimumSteps(self, s: str) -> int:
        n = len(s)
        swaps = 0
        count_ones = 0
        for i in range(n):
            if s[i] == '1':
                count_ones += 1
            elif s[i] == '0':
                swaps += count_ones
        
        return swaps