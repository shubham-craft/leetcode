class Solution:
    def maxProfitAssignment(self, difficulty: List[int], profit: List[int], worker: List[int]) -> int:
        paired = sorted(zip(profit, difficulty), key=lambda x: x[0], reverse=True)
        profit, difficulty = map(list, zip(*paired))

        worker.sort(reverse = True)

        n = len(profit)
        m = len(worker)

        ability = 0
        job = 0

        max_profit = 0
        while ability < m and job < n:
            if worker[ability] >= difficulty[job]:
                max_profit += profit[job]
                ability += 1
            else:
                job += 1
        
        # print(profit)
        # print(difficulty)
        # print(worker)
        return max_profit