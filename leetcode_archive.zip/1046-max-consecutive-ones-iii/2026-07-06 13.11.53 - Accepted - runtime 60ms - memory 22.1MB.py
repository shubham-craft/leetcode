class Solution:
    def longestOnes(self, nums: List[int], k: int) -> int:
        max_length = 0
        left = 0
        n = len(nums)
        zero_count = 0
        for right in range(n):
            if nums[right] == 0:
                zero_count += 1

            while zero_count > k:
                left_num = nums[left]
                if left_num == 0:
                    zero_count -= 1
                left += 1
            
            window_length = right - left + 1
            
            max_length = max(max_length, window_length)

        return max_length