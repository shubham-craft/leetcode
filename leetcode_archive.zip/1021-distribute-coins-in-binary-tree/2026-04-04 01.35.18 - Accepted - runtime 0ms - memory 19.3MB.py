# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def distributeCoins(self, root: Optional[TreeNode]) -> int:
        self.distribution = 0
        def dfs(root):
            if not root:
                return 0
            
            left_balance = dfs(root.left)
            right_balance = dfs(root.right)

            self.distribution += abs(left_balance) + abs(right_balance)

            my_balance = root.val + left_balance + right_balance - 1

            return my_balance
        
        dfs(root)
        return self.distribution