class Solution:
    def checkString(self, s: str) -> bool:
        n = len(s)
        last_a = -1
        first_b = n
        for i in range(n):
            letter = s[i]
            if letter == 'a':
                last_a = i
            else:
                first_b = i
            
            if last_a > first_b:
                return False
        
        return True