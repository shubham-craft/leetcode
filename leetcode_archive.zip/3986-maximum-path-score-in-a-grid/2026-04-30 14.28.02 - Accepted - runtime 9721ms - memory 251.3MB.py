class Solution:
    def maxPathScore(self, grid: List[List[int]], k: int) -> int:
        if not grid:
            return -1
        score_hashmap = {0 : 0, 1 : 1, 2 : 2}
        cost_hashmap = {0 : 0, 1 : 1, 2 : 1}
        rows = len(grid)
        cols = len(grid[0])
        # memo = {}
        memo = [[[None] * (k+1) for _ in range(cols)] for _ in range(rows)]
        def dfs(row, col, rem_k):
            if row >= rows or col >= cols:
                return float('-inf')

            curr_cell = grid[row][col]
            score_curr_cell = score_hashmap[curr_cell]
            cost_curr_cell = cost_hashmap[curr_cell]
            
            if rem_k - cost_curr_cell < 0:
                return float('-inf')

            if row == rows-1 and col == cols-1:
                return score_curr_cell
            
            # if (row,col,rem_k) in memo:
            #     return memo[(row,col,rem_k)]
            if memo[row][col][rem_k] is not None: #keep an eye on this
                return memo[row][col][rem_k] #this memo saves MLE

            next_rem_k = rem_k - cost_curr_cell
            
            down = score_curr_cell + dfs(row+1, col, next_rem_k)
            right = score_curr_cell + dfs(row, col+1, next_rem_k)

            res = max(down, right)
            # memo[(row,col,rem_k)] = res
            # return memo[(row,col,rem_k)]
            memo[row][col][rem_k] = res
            return memo[row][col][rem_k]
        
        ans = dfs(0,0,k)
        if ans == float('-inf'):
            return -1
        else:
            return ans