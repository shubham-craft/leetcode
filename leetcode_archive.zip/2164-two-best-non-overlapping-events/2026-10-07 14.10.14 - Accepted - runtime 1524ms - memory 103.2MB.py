class Solution:
    def maxTwoEvents(self, events: list[list[int]]) -> int:
        events = sorted(events, key = lambda x : (x[0], x[1]))
        start_times = [x[0] for x in events]
        n = len(start_times)
        memo = {}
        def dp(curr, rem_events):
            if curr >= n:
                return 0
            if rem_events <= 0:
                return 0
            if (curr, rem_events) in memo:
                return memo[(curr, rem_events)]
            
            curr_start = events[curr][0]
            curr_end = events[curr][1]
            curr_value = events[curr][2]

            skip = 0 + dp(curr+1, rem_events)

            next_choice = n
            left = curr+1
            right = n-1
            while left <= right:
                mid = left + (right-left)//2
                if start_times[mid] > curr_end:
                    next_choice = mid
                    right = mid-1
                else:
                    left = mid+1
            
            take = curr_value + dp(next_choice, rem_events-1)

            res = max(skip, take)
            memo[(curr, rem_events)] = res
            return memo[(curr, rem_events)]
        
        
        return dp(0, 2)