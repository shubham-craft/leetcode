class Solution:
    def winnerSquareGame(self, n: int) -> bool:
        if n == 1:
            return True
        
        memo = {}
        def dp(rem_stones):
            if rem_stones == 0:
                return False
            
            if rem_stones in memo:
                return memo[rem_stones]

            max_square_root_possible = int(rem_stones ** 0.5)
            for number in range(1, max_square_root_possible + 1):
                perfect_square = number * number
                opponent_choice = dp(rem_stones - perfect_square)

                if not opponent_choice:
                    memo[rem_stones] = True
                    return memo[rem_stones]
            
            memo[rem_stones] = False
            return memo[rem_stones]
        
        return dp(n)