class Solution:
    def totalNumbers(self, digits: List[int]) -> int:
        n = len(digits)
        seen = set()
        for first_digit in range(n-2):
            for second_digit in range(first_digit+1, n-1):
                for third_digit in range(second_digit+1, n):                    
                    first_number = digits[first_digit]
                    second_number = digits[second_digit]
                    third_number = digits[third_digit]

                    first_formed_number = (first_number*100) + (second_number*10) + (third_number)
                    if first_formed_number > 99 and first_formed_number % 2 == 0:
                        seen.add(first_formed_number)
                    
                    fourth_formed_number = (first_number*100) + (third_number*10) + (second_number)
                    if fourth_formed_number > 99 and fourth_formed_number % 2 == 0:
                        seen.add(fourth_formed_number)
                    
                    second_formed_number = (third_number*100) + (first_number*10) + (second_number)
                    if second_formed_number > 99 and second_formed_number % 2 == 0:
                        seen.add(second_formed_number)
                    
                    fifth_formed_number = (third_number*100) + (second_number*10) + (first_number)
                    if fifth_formed_number > 99 and fifth_formed_number % 2 == 0:
                        seen.add(fifth_formed_number)

                    third_formed_number = (second_number*100) + (third_number*10) + (first_number)
                    if third_formed_number > 99 and third_formed_number % 2 == 0:
                        seen.add(third_formed_number)
                    
                    sixth_formed_number = (second_number*100) + (first_number*10) + (third_number)
                    if sixth_formed_number > 99 and sixth_formed_number % 2 == 0:
                        seen.add(sixth_formed_number)
                    
        
        return len(seen)
