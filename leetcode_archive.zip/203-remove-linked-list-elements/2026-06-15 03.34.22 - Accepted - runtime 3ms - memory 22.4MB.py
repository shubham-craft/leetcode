# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def removeElements(self, head: Optional[ListNode], val: int) -> Optional[ListNode]:
        if head is None:
            return None
        
        dummy = ListNode(0)
        dummy.next = head
        temp = dummy
        while temp.next is not None:
            next_node = temp.next
            if next_node.val == val:
                temp.next = temp.next.next
            else:
                temp = temp.next
        
        return dummy.next