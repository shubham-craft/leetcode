class Solution:
    def isPalindrome(self, x: int) -> bool:
        if x<0:
            return False
        if x==0:
            return True
        
        lst = []
        while x>0:
            rem = x % 10
            x = x // 10
            lst.append(rem)

        print(lst)
        if(len(lst) == 1):
            return True
        start = 0
        end = len(lst) - 1
        while start < end:
            if lst[start] == lst[end]:
                start += 1
                end -= 1
                continue
            else:
                return False

        return True