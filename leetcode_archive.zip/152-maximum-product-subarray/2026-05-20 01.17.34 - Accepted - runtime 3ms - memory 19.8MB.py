class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        n = len(nums)
        product_max = nums[0]
        product_min = nums[0]
        maxx = nums[0]
        for i in range(1, n):
            num = nums[i]
            product1 = num * product_max
            product2 = num * product_min

            product_max = max(num, product1, product2)
            product_min = min(num, product1, product2)

            maxx = max(maxx, product_max)
        
        return maxx