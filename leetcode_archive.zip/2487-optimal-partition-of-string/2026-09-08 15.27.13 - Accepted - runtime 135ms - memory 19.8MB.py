class Solution:
    def partitionString(self, s: str) -> int:
        n = len(s)
        hashmap = {}
        possible_partitions = 1
        left = 0
        for right in range(n):
            char = s[right]
            if char not in hashmap:
                hashmap[char] = 1
            else:
                hashmap[char] += 1
                while left != right:
                    left_char = s[left]
                    hashmap[left_char] -= 1
                    if hashmap[left_char] == 0:
                        del hashmap[left_char]
                    left += 1
                
                possible_partitions += 1
        
        return possible_partitions