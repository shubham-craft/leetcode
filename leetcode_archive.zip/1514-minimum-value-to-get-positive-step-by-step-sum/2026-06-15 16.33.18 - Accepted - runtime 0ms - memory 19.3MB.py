class Solution:
    def minStartValue(self, nums: List[int]) -> int:
        min_pos_value = 1
        prefix_sum = 0
        for num in nums:
            prefix_sum += num
            min_pos_value = min(min_pos_value, prefix_sum)
        
        if min_pos_value > 0:
            return min_pos_value
        else:
            return abs(min_pos_value) + 1