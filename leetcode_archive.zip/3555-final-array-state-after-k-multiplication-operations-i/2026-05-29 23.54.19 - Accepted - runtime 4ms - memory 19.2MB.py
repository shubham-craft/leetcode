class Solution:
    def getFinalState(self, nums: List[int], k: int, multiplier: int) -> List[int]:
        while k > 0:
            min_val = float('inf')
            for num in nums:
                min_val = min(min_val, num)
            
            for idx, num in enumerate(nums):
                if num == min_val:
                    nums[idx] = num * multiplier
                    k -= 1
                    break
        
        return nums