class Solution:
    def twoCitySchedCost(self, costs: list[list[int]]) -> int:
        n = len(costs)
        diffA_diffB = []
        for i in range(n):
            cityA = costs[i][0]
            cityB = costs[i][1]
            diff = cityA - cityB
            diffA_diffB.append((diff, i))
        
        sorted_by_diff = sorted(diffA_diffB, key=lambda x: x[0])

        cost = 0
        for i in range(n):
            if i < (n//2):
                cityA_cost = sorted_by_diff[i][1]
                cost += costs[cityA_cost][0]
            else:
                cityB_cost = sorted_by_diff[i][1]
                cost += costs[cityB_cost][1]
        
        return cost