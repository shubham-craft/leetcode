class Solution:
    def findArray(self, pref: List[int]) -> List[int]:
        n = len(pref)
        result = [0] * n
        result[0] = pref[0]
        curr_xor = pref[0]
        for i in range(1, n):
            result[i] = curr_xor ^ pref[i]
            curr_xor ^= result[i]
        
        return result