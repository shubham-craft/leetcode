class Solution:
    def capitalizeTitle(self, title: str) -> str:
        string_list = title.split(" ")
        for idx, word in enumerate(string_list):
            new_word = word.lower()
            if len(new_word) > 2:                
                new_word  = new_word.title()
            string_list[idx] = new_word
        
        return " ".join(string_list)