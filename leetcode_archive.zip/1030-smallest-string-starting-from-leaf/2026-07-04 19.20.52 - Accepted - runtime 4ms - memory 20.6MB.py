# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def smallestFromLeaf(self, root: Optional[TreeNode]) -> str:
        res = []
        def dfs(root, path):
            if not root:
                return
            path += chr(root.val + ord('a'))

            if not root.left and not root.right:
                res.append(path[::-1])
                return
                
            if root.left:
                dfs(root.left, path)
            if root.right:
                dfs(root.right, path)
            
        dfs(root, "")

        smallest = res[0]
        for i in range(1, len(res)):
            if res[i] < smallest:
                smallest = res[i]
        
        return smallest