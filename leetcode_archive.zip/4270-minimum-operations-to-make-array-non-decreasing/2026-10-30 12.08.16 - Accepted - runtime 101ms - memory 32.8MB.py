class Solution:
    def minOperations(self, nums: list[int]) -> int:
        n = len(nums)
        x = 0
        prev = nums[0]
        for i in range(1, n):
            curr = nums[i]
            if (curr + x) < (prev):
                x += prev - (curr + x)
            
            prev = (curr + x)
            

        return x 