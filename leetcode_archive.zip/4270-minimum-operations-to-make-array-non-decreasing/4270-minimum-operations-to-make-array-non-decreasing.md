<h1>4270 - Minimum Operations to Make Array Non Decreasing</h1><h2>Difficulty: Medium - <a href="https://leetcode.com/problems/minimum-operations-to-make-array-non-decreasing/">minimum-operations-to-make-array-non-decreasing</a></h2><p data-end="140" data-start="88">You are given an integer array <code>nums</code> of length <code>n</code>.</p>

<p>In one operation, you may choose any <strong><span data-keyword="subarray-nonempty">subarray</span></strong> <code>nums[l..r]</code> and <strong>increase</strong> each element in that <strong>subarray</strong> by <code>x</code>, where <code>x</code> is any <strong>positive</strong> integer.</p>

<p>Return the <strong>minimum</strong> possible <strong>sum</strong> of the values of <code>x</code> across all operations required to make the array <strong>non-decreasing</strong>.</p>

<p>An array is <strong>non-decreasing</strong> if <code>nums[i] &lt;= nums[i + 1]</code> for all <code>0 &lt;= i &lt; n - 1</code>.</p>

<p>&nbsp;</p>
<p><strong class="example">Example 1:</strong></p>

<div class="example-block">
<p><strong>Input:</strong> <span class="example-io">nums = [3,3,2,1]</span></p>

<p><strong>Output:</strong> <span class="example-io">2</span></p>

<p><strong>Explanation:</strong></p>

<p>One optimal set of operations:</p>

<ul>
	<li>Choose subarray <code>[2..3]</code> and add <code>x = 1</code> resulting in <code>[3, 3, 3, 2]</code></li>
	<li>Choose subarray <code>[3..3]</code> and add <code>x = 1</code> resulting in <code>[3, 3, 3, 3]</code></li>
</ul>

<p>The array becomes non-decreasing, and the total sum of chosen <code>x</code> values is <code>1 + 1 = 2</code>.</p>
</div>

<p><strong class="example">Example 2:</strong></p>

<div class="example-block">
<p><strong>Input:</strong> <span class="example-io">nums = [5,1,2,3]</span></p>

<p><strong>Output:</strong> <span class="example-io">4</span></p>

<p><strong>Explanation:</strong></p>

<p>One optimal set of operations:</p>

<ul>
	<li>Choose subarray <code>[1..3]</code> and add <code>x = 4</code> resulting in <code>[5, 5, 6, 7]</code></li>
</ul>

<p>The array becomes non-decreasing, and the total sum of chosen <code>x</code> values is <code>4</code>.</p>
</div>

<p>&nbsp;</p>
<p><strong>Constraints:</strong></p>

<ul>
	<li><code>1 &lt;= n == nums.length &lt;= 10<sup>5</sup></code></li>
	<li><code>1 &lt;= nums[i] &lt;= 10<sup>9</sup></code></li>
</ul>
