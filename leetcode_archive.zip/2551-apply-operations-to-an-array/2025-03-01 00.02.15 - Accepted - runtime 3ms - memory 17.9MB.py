class Solution:
    def applyOperations(self, nums: List[int]) -> List[int]:
        for i in range(len(nums) - 1):
            j = i+1
            if nums[i] == nums[j]:
                nums[i] = nums[i] * 2
                nums[j] = 0
        
        count = 0
    
        for i in range(len(nums)):
            if nums[i] != 0:
                nums[i], nums[count] = nums[count], nums[i]
                count += 1
            
        print(nums)
        return nums