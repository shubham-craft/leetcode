class Solution:
    def maximumAmount(self, coins: List[List[int]]) -> int:
        rows = len(coins)
        cols = len(coins[0])
        memo = [[[None] * 3 for _ in range(cols)] for _ in range(rows)]

        def dfs(row, col, rem_neut):
            if row >= rows or col >= cols:
                return float('-inf')

            curr_cell = coins[row][col]
            if row == rows-1 and col == cols-1:
                if curr_cell < 0 and rem_neut > 0:
                    return 0
                else:
                    return curr_cell
                
            if memo[row][col][rem_neut] is not None:
                return memo[row][col][rem_neut]
            
            down = curr_cell + dfs(row+1, col, rem_neut)
            right = curr_cell + dfs(row, col+1, rem_neut)
            res = max(down, right)

            if curr_cell < 0 and rem_neut > 0:
                down_neut = dfs(row+1, col, rem_neut-1)
                right_neut = dfs(row, col+1, rem_neut-1)

                res = max(res, down_neut, right_neut)

            memo[row][col][rem_neut] = res
            return memo[row][col][rem_neut]
        
        return dfs(0,0,2)