class Solution:
    def smallestRange(self, nums: List[List[int]]) -> List[int]:
        n = len(nums)
        total = 0
        for i in range(n):
            for j in range(len(nums[i])):
                total += 1

        min_heap = []
        min_num = float('inf')
        max_num = float('-inf')
        for i in range(n):
            heapq.heappush(min_heap, (nums[i][0], i, 0))
            min_num = min(min_num, nums[i][0])
            max_num = max(max_num, nums[i][0])

        res = [min_num, max_num]

        for i in range(total):
            min_num, list_number, index = heapq.heappop(min_heap)

            if max_num - min_num < res[1] - res[0]:
                res = [min_num, max_num]

            if index+1 < len(nums[list_number]):
                heapq.heappush(min_heap, (nums[list_number][index+1], list_number, index+1))
                max_num = max(max_num, nums[list_number][index+1])
            else:
                break

        return res