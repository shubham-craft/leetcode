class Solution:
    def minReorder(self, n: int, connections: List[List[int]]) -> int:
        graph = {i : [] for i in range(n)}
        for a, b in connections:
            graph[a].append((b, 1))
            graph[b].append((a, 0))
        
        visited = set()
        def dfs(node):
            visited.add(node)
            reorient = 0
            for nei, cost in graph[node]:
                if nei not in visited:
                    reorient += cost + dfs(nei)
            
            return reorient
        
        return dfs(0)