class Solution:
    def numWays(self, steps: int, arrLen: int) -> int:
        MOD = 10**9 + 7
        memo = {}
        def dfs(pos, steps_taken):
            if steps_taken == steps and pos == 0:
                return 1
            if abs(pos - 0) > (steps - steps_taken):
                return 0
            if pos < 0 or pos >= arrLen:
                return 0
            if steps_taken > steps:
                return 0
            if (pos, steps_taken) in memo:
                return memo[(pos, steps_taken)]
            
            curr_pos = pos
            curr_steps = steps_taken

            left = dfs(curr_pos-1, curr_steps+1)
            right = dfs(curr_pos+1, curr_steps+1)
            stay = dfs(curr_pos, curr_steps+1)

            res = (left + right + stay) % MOD
            memo[(pos, steps_taken)] = res
            return memo[(pos, steps_taken)]
        
        return dfs(0, 0)