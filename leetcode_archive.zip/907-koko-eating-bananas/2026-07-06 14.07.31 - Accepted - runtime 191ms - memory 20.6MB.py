class Solution:
    def minEatingSpeed(self, piles: List[int], h: int) -> int:
        def can_eat(bananas_per_hour):
            total_hours = 0
            for pile in piles:
                pile_speed = (pile + bananas_per_hour - 1) // bananas_per_hour
                total_hours += pile_speed
            
            return total_hours <= h
        
        left = 1
        right = max(piles)
        ans = right
        while left <= right:
            mid = left + (right-left)//2
            if can_eat(mid):
                ans = mid
                right = mid-1
            else:
                left = mid+1
        
        return ans