class Solution:
    def maximumCandies(self, candies: List[int], k: int) -> int:
        n = len(candies)
        if k > sum(candies):
            return 0
        
        def can_distribute(candies_per_child):
            kids_fed = 0
            for candy in candies:
                kids_fed += candy // candies_per_child
            
            return kids_fed >= k

        left = 1
        right = sum(candies)
        while left <= right:
            mid = left + (right-left)//2
            if can_distribute(mid):
                ans = mid
                left = mid+1
            else:
                right = mid-1
        
        return ans