class Solution:
    def wordPattern(self, pattern: str, s: str) -> bool:
        # print(s.split(' ')[1])
        hashset = {}
        word = 0
        if len(s.split(' ')) != len(pattern):
            return False

        for element in pattern:
            if element in hashset and hashset[element] != s.split(' ')[word]:
                return False
            else:
                hashset[element] = s.split(' ')[word]
                word += 1

        if len(hashset.values()) != len(set(s.split(' '))):
            return False
        
        print(hashset)
        return True

        