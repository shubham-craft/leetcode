# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def reverseBetween(self, head: Optional[ListNode], left: int, right: int) -> Optional[ListNode]:
        dummy = ListNode(0)
        difference = right - left
        dummy.next = head
        prev_node = dummy
        after_node = dummy
        while left > 1:
            prev_node = prev_node.next
            left = left - 1

        while right >= 0:
            after_node = after_node.next
            right = right - 1

        # print(prev_node)
        # print(after_node)
        node_to_reverse = prev_node.next
        while difference >= 0:
                temp = node_to_reverse.next
                node_to_reverse.next = after_node
                after_node = node_to_reverse
                node_to_reverse = temp
                difference -= 1
        
        # print(node_to_reverse)

        prev_node.next = after_node

        return dummy.next       