class Solution:
    def maxProfit(self, prices: List[int], fee: int) -> int:
        memo = {}
        def dfs(i, buying):
            if i >= len(prices):
                return 0
            if (i, buying) in memo:
                return memo[(i, buying)]
            if buying == True:
                bought = -prices[i] + dfs(i+1, False)
                skipped = 0 + dfs(i+1, True)
                res = max(bought, skipped)
            else:
                sold = prices[i] + dfs(i+1, True) - fee
                skipped = 0 + dfs(i+1, False)
                res = max(sold, skipped)
            
            memo[(i, buying)] = res
            return memo[(i, buying)]
        
        return dfs(0, True)