class Solution:
    def minimumPushes(self, word: str) -> int:
        n = len(word)
        quotient = n // 8
        remainder = n % 8

        if n <= 8:
            total = n
        elif 8 < n <= 16:
            total = 8 + (2 * (n-8))
        elif 16 < n <= 24:
            total = 24 + (3 * (n-16))
        else:
            total = 48 + (4 * (n - 24))

        return total