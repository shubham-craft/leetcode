class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        n = len(strs)
        if n == 0:
            return ""
        if n == 1:
            return strs[0]
        strs.sort()
        first = strs[0]
        last = strs[-1]
        longest_prefix = ""
        left = 0
        right = 0
        while left < len(first) and right < len(last):
            if first[left] == last[right]:
                longest_prefix += first[left]
            else:
                break
            
            left += 1
            right += 1
        
        return longest_prefix