class Solution:
    def maxProfit(self, k: int, prices: List[int]) -> int:
        n = len(prices)
        memo = {}
        def dfs(idx, buying, rem_k):
            if idx == n:
                return 0
            if rem_k == 0:
                return 0
            if (idx, buying, rem_k) in memo:
                return memo[(idx, buying, rem_k)]
            
            if buying == True:
                bought = -prices[idx] + dfs(idx+1, False, rem_k)
                skipped = 0 + dfs(idx+1, True, rem_k)
                res = max(bought, skipped)
            else:
                sold = prices[idx] + dfs(idx+1, True, rem_k-1)
                skipped = 0 + dfs(idx+1, False, rem_k)
                res = max(sold, skipped)
            
            memo[(idx, buying, rem_k)] = res
            return memo[(idx, buying, rem_k)]
        
        return dfs(0, True, k)