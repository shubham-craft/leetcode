class Solution:
    def frequencySort(self, nums: List[int]) -> List[int]:
        hashmap = {}
        for num in nums:
            if num not in hashmap:
                hashmap[num] = 1
            else:
                hashmap[num] += 1
        
        min_heap = []
        for key, value in hashmap.items():
            heapq.heappush(min_heap, (value, -key))

        result = []
        while min_heap:
            frequency, number = heapq.heappop(min_heap)
            number *= -1
            for f in range(frequency):
                result.append(number)
        
        return result