class Solution:
    def stoneGameII(self, piles: List[int]) -> int:
        n = len(piles)
        suffix = [0] * n
        suffix[-1] = piles[-1]
        for i in range(n-2,-1,-1):
            suffix[i] = suffix[i+1] + piles[i]

        memo = {}
        def dfs(i, M):
            if i == n:
                return 0
            if i+2*M >= n:
                return suffix[i]
            if (i, M) in memo:
                return memo[(i, M)]
            
            res = float('-inf')
            for X in range(1, 2*M + 1):
                opponent_choice = dfs(X+i, max(M,X))
                my_choice = suffix[i] - opponent_choice
                res = max(res, my_choice)
            
            memo[(i, M)] = res
            return memo[(i, M)]
        
        return dfs(0,1)