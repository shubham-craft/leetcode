# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def goodNodes(self, root: TreeNode) -> int:
        self.total = 0
        def dfs(node, curr_top_value):
            if not node:
                return
            
            my_val = node.val
            if my_val >= curr_top_value:
                self.total += 1
                curr_top_value = my_val
            
            left_check = dfs(node.left, curr_top_value)
            right_check = dfs(node.right, curr_top_value)
        
        dfs(root, float('-inf'))
        return self.total