class Solution:
    def isNStraightHand(self, hand: list[int], groupSize: int) -> bool:
        n = len(hand)
        if n % groupSize != 0:
            return False
        
        min_heap = []
        hashmap = {}
        for number in hand:
            if number not in hashmap:
                hashmap[number] = 1
                heapq.heappush(min_heap, number)
            else:
                hashmap[number] += 1
        
        while min_heap:
            smallest_number = heapq.heappop(min_heap)
            if hashmap[smallest_number] == 0:
                continue
            
            for seq in range(smallest_number, (groupSize + smallest_number)):
                if seq not in hashmap or hashmap[seq] == 0:
                    return False
                hashmap[seq] -= 1
            
            if hashmap[smallest_number] > 0:
                heapq.heappush(min_heap, smallest_number)
        
        return True