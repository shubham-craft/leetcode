# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def pathSum(self, root: TreeNode | None, targetSum: int) -> list[list[int]]:
        result = []
        def pre_order(node, curr_path, path_sum):
            if not node:
                return 0
            
            new_sum = path_sum + node.val
            new_path = curr_path + [node.val]

            if not node.left and not node.right and new_sum == targetSum:
                result.append(new_path)
                return
            
            if node.left:
                pre_order(node.left, new_path, new_sum)
            if node.right:
                pre_order(node.right, new_path, new_sum)
        
        pre_order(root, [], 0)
        return result