class Solution:
    def minimumIndex(self, capacity: list[int], itemSize: int) -> int:
        min_capacity = float('inf')
        min_index = float('inf')
        for index in range(len(capacity)):
            if capacity[index] >= itemSize and min_capacity > capacity[index]:
                min_capacity = capacity[index]
                min_index = index
        
        if min_index != float('inf'):
            return min_index
        else:
            return -1
