class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        # #instead of dp, try using binary search methid and patience sort for this problem
        # #top-dwon memoization dp is giving MLE here
        subsequence = []
        def binarySearch(sub_list, target):
            left = 0
            right = len(sub_list) - 1

            while left <= right:
                mid = left + (right-left)//2
                if sub_list[mid] == target:
                    return mid
                elif sub_list[mid] < target:
                    left = mid+1
                else:
                    right = mid-1
            
            return left

        for num in nums:
            if len(subsequence) == 0 or num > subsequence[-1]:
                subsequence.append(num)
            else:
                index = binarySearch(subsequence, num)
                subsequence[index] = num
        
        return len(subsequence)

        # memo = {}
        # def dfs(idx, prev_idx):
        #     if idx == len(nums):
        #         return 0
        #     if (idx, prev_idx) in memo:
        #         return memo[(idx, prev_idx)]
            
        #     skip = 0 + dfs(idx+1, prev_idx)

        #     take = 0
        #     if prev_idx == -1 or nums[idx] > nums[prev_idx]:
        #         take = 1 + dfs(idx+1, idx)
            
        #     res = max(skip, take)

        #     memo[(idx, prev_idx)] = res
        #     return memo[(idx, prev_idx)]
    
        # return dfs(0, -1)