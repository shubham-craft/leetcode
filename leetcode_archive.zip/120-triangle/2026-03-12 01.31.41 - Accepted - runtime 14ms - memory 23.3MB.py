class Solution:
    def minimumTotal(self, triangle: List[List[int]]) -> int:
        memo = {}
        rows = len(triangle)

        def dfs(row, col):
            if row == rows:
                return 0
            if (row, col) in memo:
                return memo[(row, col)] 

            res = float('inf')
            down = dfs(row+1, col)
            right = dfs(row+1, col+1)

            res = triangle[row][col] + min(down, right)
            memo[(row, col)] = res
            return memo[(row, col)]
        
        return dfs(0,0)