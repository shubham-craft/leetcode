class Solution:
    def longestBalanced(self, nums: List[int]) -> int:
        max_length = 0
        n = len(nums)
        for i in range(n):
            even_set = set()
            odd_set = set()
            for j in range(i, n):
                num = nums[j]
                if num%2 == 0:
                    even_set.add(num)
                else:
                    odd_set.add(num)

                if len(even_set) == len(odd_set):
                    length = (j-i+1)
                    max_length = max(length, max_length)
        
        return max_length