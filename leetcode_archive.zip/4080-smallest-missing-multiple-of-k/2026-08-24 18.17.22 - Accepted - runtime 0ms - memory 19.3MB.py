class Solution:
    def missingMultiple(self, nums: List[int], k: int) -> int:
        hashset = set()
        for num in nums:
            if num % k == 0:
                hashset.add(num)
        
        if k not in hashset:
            return k
        
        multiple = k
        while multiple in hashset:
            hashset.remove(multiple)
            multiple += k
        
        return multiple