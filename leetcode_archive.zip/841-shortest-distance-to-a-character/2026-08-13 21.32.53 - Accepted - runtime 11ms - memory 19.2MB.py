class Solution:
    def shortestToChar(self, s: str, c: str) -> List[int]:
        hashmap = {}
        for index, char in enumerate(s):
            if char != c:
                continue

            if char not in hashmap:
                hashmap[char] = [index]
            else:
                hashmap[char].append(index)
        
        c_indexes = hashmap[c]
        
        def shortest(pos):
            shortest_dist = float('inf')
            for i in c_indexes:
                dist = abs(pos - i)
                shortest_dist = min(shortest_dist, dist)
                if dist > shortest_dist:
                    break
            
            return shortest_dist

        result = [0] * len(s)
        for index, char in enumerate(s):
            if char == c:
                result[index] = 0
            else:
                min_dist = shortest(index)
                result[index] =  min_dist
        
        return result
