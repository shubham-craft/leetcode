class Solution:
    def areSimilar(self, mat: List[List[int]], k: int) -> bool:
        if not mat:
            return True
        rows = len(mat)
        cols = len(mat[0])
        shift_param = k%cols

        for row in range(rows):
            for col in range(cols):
                if row%2 == 0:
                    if mat[row][col] != mat[row][(col+shift_param)%cols]:
                        return False
                else:
                    if mat[row][col] != mat[row][(col-shift_param)%cols]:
                        return False
        
        return True