class Solution:
    def gameOfLife(self, board: List[List[int]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        rows = len(board)
        cols = len(board[0])
        dummy_board = [[0 for _ in range(cols)] for _ in range(rows)]
        visited = set()        
        queue = deque([(0,0)])

        while queue:
            row, col = queue.popleft()
            val = board[row][col]
            if (row, col) in visited:
                continue
            visited.add((row, col))

            dead = 0
            alive = 0
            if col+1 < cols:
                right = (row, col+1)
                if board[row][col+1] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row, col+1))
            
            if col-1 >= 0:
                left = (row, col-1)
                if board[row][col-1] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row, col-1))
            
            if row+1 < rows:
                down = (row+1, col)
                if board[row+1][col] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row+1, col))
            
            if row-1 >= 0:
                up = (row-1, col)
                if board[row-1][col] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row-1, col))
            
            if row+1 < rows and col+1 < cols:
                down_right = (row+1, col+1)
                if board[row+1][col+1] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row+1, col+1))
            
            if row+1 < rows and col-1 >= 0:
                down_left = (row+1, col-1)
                if board[row+1][col-1] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row+1, col-1))
            
            if row-1 >= 0 and col+1 < cols:
                up_right = (row-1, col+1)
                if board[row-1][col+1] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row-1, col+1))
            
            if row-1 >= 0 and col-1 >= 0:
                up_left = (row-1, col-1)
                if board[row-1][col-1] == 1:
                    alive += 1
                else:
                    dead += 1
                queue.append((row-1, col-1))
            
            if val == 1:
                if alive < 2 or alive > 3:
                    dummy_board[row][col] = 0
                elif alive == 2 or alive == 3:
                    dummy_board[row][col] = 1
            else:
                if alive == 3:
                    dummy_board[row][col] = 1
        
        board[:] = dummy_board