class Solution:
    def minHeightShelves(self, books: List[List[int]], shelfWidth: int) -> int:
        n = len(books)
        memo = {}
        def dfs(i, prev_height, rem_width):
            if rem_width < 0:
                return float('inf')
            if i == n:
                return 0            
            if(i, prev_height, rem_width) in memo:
                return memo[(i, prev_height, rem_width)]
            
            curr_height = books[i][1]
            curr_width = books[i][0]

            if prev_height == -1:
                new = curr_height + dfs(i+1, curr_height, shelfWidth - curr_width)
                res = new
            elif curr_height <= prev_height:
                same = 0 + dfs(i+1, prev_height, rem_width - curr_width)
                new = curr_height + dfs(i+1, curr_height, shelfWidth - curr_width)
                res = min(same, new)
            else:
                height_diff = curr_height - prev_height
                same = height_diff + dfs(i+1, curr_height, rem_width - curr_width)
                new = curr_height + dfs(i+1, curr_height, shelfWidth - curr_width)
                res = min(same, new)
            
            memo[(i, prev_height, rem_width)] = res
            return memo[(i, prev_height, rem_width)]
        
        return dfs(0, -1, shelfWidth)