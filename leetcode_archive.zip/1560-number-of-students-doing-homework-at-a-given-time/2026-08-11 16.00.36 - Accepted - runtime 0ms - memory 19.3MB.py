class Solution:
    def busyStudent(self, startTime: List[int], endTime: List[int], queryTime: int) -> int:
        total = 0
        for start, end in zip(startTime, endTime):
            if start <= queryTime <= end:
                total += 1
        
        return total