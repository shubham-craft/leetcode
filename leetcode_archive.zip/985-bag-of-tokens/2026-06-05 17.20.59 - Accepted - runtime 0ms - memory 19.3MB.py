class Solution:
    def bagOfTokensScore(self, tokens: List[int], power: int) -> int:
        tokens.sort()
        n = len(tokens)
        left = 0
        right = n - 1
        score = 0
        max_score = 0
        while left <= right:
            if power >= tokens[left]:
                score += 1
                power -= tokens[left]
                max_score = max(max_score, score)
            else:
                if score >= 1:
                    score -= 1
                    power += tokens[right]
                    right -= 1
                    continue
            
            left += 1
        
        return max_score