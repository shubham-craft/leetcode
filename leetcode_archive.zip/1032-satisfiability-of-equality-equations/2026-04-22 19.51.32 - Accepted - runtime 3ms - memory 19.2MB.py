class UnionFind:
    def __init__(self, n):
        self.parent = [i for i in range(n)]
        self.rank = [1] * n
    
    def find(self, x):
        if self.parent[x] == x:
            return x
        
        self.parent[x] = self.find(self.parent[x])

        return self.parent[x]
    
    def union(self, x, y):
        root_x = self.find(x)
        root_y = self.find(y)

        if root_x == root_y:
            return False
        
        if self.rank[root_x] > self.rank[root_y]:
            self.parent[root_y] = root_x
        elif self.rank[root_x] < self.rank[root_y]:
            self.parent[root_x] = root_y
        else:
            self.parent[root_y] = root_x
            self.rank[root_x] += 1
        
        return True

class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        n = 26
        equal = []
        inequal = []
        uf = UnionFind(n)

        for equation in equations:
            if equation[1:3] == '==':
                char_1 = equation[0]
                char_2 = equation[3]
                ord_1 = ord(char_1) - ord('a')
                ord_2 = ord(char_2) - ord('a')
                if uf.union(ord_1,ord_2):
                    equal.append((ord_1,ord_2))
        
        print(equal)
        
        for equation in equations:
            if equation[1:3] == '!=':
                char_1 = equation[0]
                char_2 = equation[3]
                ord_1 = ord(char_1) - ord('a')
                ord_2 = ord(char_2) - ord('a')
                root_1 = uf.find(ord_1)
                root_2 = uf.find(ord_2)
                if root_1 == root_2:
                    return False
        
        return True