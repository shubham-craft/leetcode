class Solution:
    def maxValueOfCoins(self, piles: List[List[int]], k: int) -> int:
        n = len(piles)
        memo = {}
        def dfs(i, rem_k):
            if rem_k == 0:
                return 0
            if i == n:
                return float('-inf')
            
            if (i, rem_k) in memo:
                return memo[(i, rem_k)]
            
            res = 0 + dfs(i+1, rem_k)

            limit = min(len(piles[i]), rem_k)

            curr_coin_sum = 0
            for j in range(limit):
                curr_coin_sum += piles[i][j]

                future = dfs(i+1, rem_k - (j+1))
            
                res =  max(res, curr_coin_sum + future)
            
            memo[(i, rem_k)] = res
            return memo[(i, rem_k)]
        
        return dfs(0, k)