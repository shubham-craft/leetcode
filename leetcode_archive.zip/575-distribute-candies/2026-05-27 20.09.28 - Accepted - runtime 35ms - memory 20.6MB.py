class Solution:
    def distributeCandies(self, candyType: List[int]) -> int:
        n = len(candyType)
        candies_allowed = n // 2
        hashmap = {}
        for candy in candyType:
            if candy not in hashmap:
                hashmap[candy] = 1
                if len(hashmap) == candies_allowed:
                    return len(hashmap)
        
        return len(hashmap)