class Solution:
    def winningPlayerCount(self, n: int, pick: List[List[int]]) -> int:
        hashmap = {}
        max_color = -1
        for player, color in pick:
            max_color = max(max_color, color)
            if player not in hashmap:
                hashmap[player] = [color]
            else:
                hashmap[player].append(color)
        
        output = 0
        for player, colors in hashmap.items():
            arr = [0] * (max_color+1)
            for color in colors:
                arr[color] += 1
                if arr[color] > player:
                    output += 1
                    break
        
        return output