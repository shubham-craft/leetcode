class Solution:
    def captureForts(self, forts: List[int]) -> int:
        max_len = curr_len = 0
        left = zero_count = 0
        right = left + 1

        while right < len(forts):
            if forts[left] == 0:
                left += 1
                right += 1
                continue

            if forts[right] == 0:
                zero_count += 1

            elif forts[left] != forts[right]:
                left = right
                curr_len = zero_count
                zero_count = 0

            else:
                left = right
                zero_count = 0
            
            right += 1
            max_len = max(max_len, curr_len)
            
        print(max_len)
        return max_len

